
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */

import java.lang.String

import org.apache.poi.ss.usermodel.Workbook

import org.apache.poi.ss.usermodel.Sheet

import org.apache.poi.ss.usermodel.Cell

import java.util.List

import java.lang.Object

import org.apache.poi.ss.usermodel.Row

import java.util.Map

import com.kms.katalon.core.testobject.TestObject



def static "com.kms.katalon.keyword.excel.ExcelKeywords.getWorkbook"(
    	String filePath	) {
    (new com.kms.katalon.keyword.excel.ExcelKeywords()).getWorkbook(
        	filePath)
}


def static "com.kms.katalon.keyword.excel.ExcelKeywords.createExcelSheet"(
    	Workbook workbook	) {
    (new com.kms.katalon.keyword.excel.ExcelKeywords()).createExcelSheet(
        	workbook)
}


def static "com.kms.katalon.keyword.excel.ExcelKeywords.createExcelSheet"(
    	Workbook workbook	
     , 	String sheetName	) {
    (new com.kms.katalon.keyword.excel.ExcelKeywords()).createExcelSheet(
        	workbook
         , 	sheetName)
}


def static "com.kms.katalon.keyword.excel.ExcelKeywords.getCellByAddress"(
    	Sheet sheet	
     , 	String cellAddress	) {
    (new com.kms.katalon.keyword.excel.ExcelKeywords()).getCellByAddress(
        	sheet
         , 	cellAddress)
}


def static "com.kms.katalon.keyword.excel.ExcelKeywords.getCellValue"(
    	Cell cell	) {
    (new com.kms.katalon.keyword.excel.ExcelKeywords()).getCellValue(
        	cell)
}


def static "com.kms.katalon.keyword.excel.ExcelKeywords.getTableContent"(
    	Sheet sheet	
     , 	int startRow	
     , 	int endRow	) {
    (new com.kms.katalon.keyword.excel.ExcelKeywords()).getTableContent(
        	sheet
         , 	startRow
         , 	endRow)
}


def static "com.kms.katalon.keyword.excel.ExcelKeywords.getDataRows"(
    	Sheet sheet	
     , 	java.util.List<java.lang.Integer> rowIndexs	) {
    (new com.kms.katalon.keyword.excel.ExcelKeywords()).getDataRows(
        	sheet
         , 	rowIndexs)
}


def static "com.kms.katalon.keyword.excel.ExcelKeywords.saveWorkbook"(
    	String filePath	
     , 	Workbook workbook	) {
    (new com.kms.katalon.keyword.excel.ExcelKeywords()).saveWorkbook(
        	filePath
         , 	workbook)
}


def static "com.kms.katalon.keyword.excel.ExcelKeywords.getExcelSheet"(
    	String filePath	) {
    (new com.kms.katalon.keyword.excel.ExcelKeywords()).getExcelSheet(
        	filePath)
}


def static "com.kms.katalon.keyword.excel.ExcelKeywords.getExcelSheet"(
    	Workbook wbs	) {
    (new com.kms.katalon.keyword.excel.ExcelKeywords()).getExcelSheet(
        	wbs)
}


def static "com.kms.katalon.keyword.excel.ExcelKeywords.getExcelSheet"(
    	String filePath	
     , 	int sheetIndex	) {
    (new com.kms.katalon.keyword.excel.ExcelKeywords()).getExcelSheet(
        	filePath
         , 	sheetIndex)
}


def static "com.kms.katalon.keyword.excel.ExcelKeywords.getExcelSheet"(
    	Workbook wbs	
     , 	String sheetName	) {
    (new com.kms.katalon.keyword.excel.ExcelKeywords()).getExcelSheet(
        	wbs
         , 	sheetName)
}


def static "com.kms.katalon.keyword.excel.ExcelKeywords.locateCell"(
    	Sheet sheet	
     , 	Object cellContent	) {
    (new com.kms.katalon.keyword.excel.ExcelKeywords()).locateCell(
        	sheet
         , 	cellContent)
}


def static "com.kms.katalon.keyword.excel.ExcelKeywords.createExcelFile"(
    	String filePath	) {
    (new com.kms.katalon.keyword.excel.ExcelKeywords()).createExcelFile(
        	filePath)
}


def static "com.kms.katalon.keyword.excel.ExcelKeywords.createWorkbook"(
    	String filePath	) {
    (new com.kms.katalon.keyword.excel.ExcelKeywords()).createWorkbook(
        	filePath)
}


def static "com.kms.katalon.keyword.excel.ExcelKeywords.getCellByIndex"(
    	Sheet sheet	
     , 	int rowIdx	
     , 	int colIdx	) {
    (new com.kms.katalon.keyword.excel.ExcelKeywords()).getCellByIndex(
        	sheet
         , 	rowIdx
         , 	colIdx)
}


def static "com.kms.katalon.keyword.excel.ExcelKeywords.compareTwoCells"(
    	Cell cell1	
     , 	Cell cell2	) {
    (new com.kms.katalon.keyword.excel.ExcelKeywords()).compareTwoCells(
        	cell1
         , 	cell2)
}


def static "com.kms.katalon.keyword.excel.ExcelKeywords.compareTwoCells"(
    	Cell cell1	
     , 	Cell cell2	
     , 	boolean isValueOnly	) {
    (new com.kms.katalon.keyword.excel.ExcelKeywords()).compareTwoCells(
        	cell1
         , 	cell2
         , 	isValueOnly)
}


def static "com.kms.katalon.keyword.excel.ExcelKeywords.compareTwoSheets"(
    	Sheet sheet1	
     , 	Sheet sheet2	
     , 	boolean isValueOnly	) {
    (new com.kms.katalon.keyword.excel.ExcelKeywords()).compareTwoSheets(
        	sheet1
         , 	sheet2
         , 	isValueOnly)
}


def static "com.kms.katalon.keyword.excel.ExcelKeywords.compareTwoSheets"(
    	Sheet sheet1	
     , 	Sheet sheet2	) {
    (new com.kms.katalon.keyword.excel.ExcelKeywords()).compareTwoSheets(
        	sheet1
         , 	sheet2)
}


def static "com.kms.katalon.keyword.excel.ExcelKeywords.compareTwoRows"(
    	Row row1	
     , 	Row row2	) {
    (new com.kms.katalon.keyword.excel.ExcelKeywords()).compareTwoRows(
        	row1
         , 	row2)
}


def static "com.kms.katalon.keyword.excel.ExcelKeywords.compareTwoRows"(
    	Row row1	
     , 	Row row2	
     , 	boolean isValueOnly	) {
    (new com.kms.katalon.keyword.excel.ExcelKeywords()).compareTwoRows(
        	row1
         , 	row2
         , 	isValueOnly)
}


def static "com.kms.katalon.keyword.excel.ExcelKeywords.compareTwoExcels"(
    	Workbook workbook1	
     , 	Workbook workbook2	) {
    (new com.kms.katalon.keyword.excel.ExcelKeywords()).compareTwoExcels(
        	workbook1
         , 	workbook2)
}


def static "com.kms.katalon.keyword.excel.ExcelKeywords.compareTwoExcels"(
    	Workbook workbook1	
     , 	Workbook workbook2	
     , 	boolean isValueOnly	) {
    (new com.kms.katalon.keyword.excel.ExcelKeywords()).compareTwoExcels(
        	workbook1
         , 	workbook2
         , 	isValueOnly)
}


def static "com.kms.katalon.keyword.excel.ExcelKeywords.setValueToCellByAddress"(
    	Sheet sheet	
     , 	String cellAddress	
     , 	Object value	) {
    (new com.kms.katalon.keyword.excel.ExcelKeywords()).setValueToCellByAddress(
        	sheet
         , 	cellAddress
         , 	value)
}


def static "com.kms.katalon.keyword.excel.ExcelKeywords.setValueToCellByAddresses"(
    	Sheet sheet	
     , 	Map content	) {
    (new com.kms.katalon.keyword.excel.ExcelKeywords()).setValueToCellByAddresses(
        	sheet
         , 	content)
}


def static "com.kms.katalon.keyword.excel.ExcelKeywords.createExcelSheets"(
    	Workbook workbook	
     , 	java.util.List<String> sheetNames	) {
    (new com.kms.katalon.keyword.excel.ExcelKeywords()).createExcelSheets(
        	workbook
         , 	sheetNames)
}


def static "com.kms.katalon.keyword.excel.ExcelKeywords.getCellIndexByAddress"(
    	Sheet sheet	
     , 	String cellAddress	) {
    (new com.kms.katalon.keyword.excel.ExcelKeywords()).getCellIndexByAddress(
        	sheet
         , 	cellAddress)
}


def static "com.kms.katalon.keyword.excel.ExcelKeywords.getCellValueByIndex"(
    	Sheet sheet	
     , 	int rowIdx	
     , 	int colIdx	) {
    (new com.kms.katalon.keyword.excel.ExcelKeywords()).getCellValueByIndex(
        	sheet
         , 	rowIdx
         , 	colIdx)
}


def static "com.kms.katalon.keyword.excel.ExcelKeywords.getCellValueByRangeAddress"(
    	Sheet sheet	
     , 	String topLeftAddress	
     , 	String rightBottomAddress	) {
    (new com.kms.katalon.keyword.excel.ExcelKeywords()).getCellValueByRangeAddress(
        	sheet
         , 	topLeftAddress
         , 	rightBottomAddress)
}


def static "com.kms.katalon.keyword.excel.ExcelKeywords.getCellValuesByRangeIndexes"(
    	Sheet sheet	
     , 	int rowInd1	
     , 	int colInd1	
     , 	int rowInd2	
     , 	int colInd2	) {
    (new com.kms.katalon.keyword.excel.ExcelKeywords()).getCellValuesByRangeIndexes(
        	sheet
         , 	rowInd1
         , 	colInd1
         , 	rowInd2
         , 	colInd2)
}


def static "com.kms.katalon.keyword.excel.ExcelKeywords.getMapOfKeyValueRows"(
    	Sheet sheet	
     , 	int keyRowIdx	
     , 	int valueRowIdx	) {
    (new com.kms.katalon.keyword.excel.ExcelKeywords()).getMapOfKeyValueRows(
        	sheet
         , 	keyRowIdx
         , 	valueRowIdx)
}


def static "com.kms.katalon.keyword.excel.ExcelKeywords.getExcelSheetByName"(
    	String filePath	
     , 	String sheetName	) {
    (new com.kms.katalon.keyword.excel.ExcelKeywords()).getExcelSheetByName(
        	filePath
         , 	sheetName)
}


def static "com.kms.katalon.keyword.excel.ExcelKeywords.setValueToCellByIndex"(
    	Sheet sheet	
     , 	int rowIndex	
     , 	int colIndex	
     , 	Object value	) {
    (new com.kms.katalon.keyword.excel.ExcelKeywords()).setValueToCellByIndex(
        	sheet
         , 	rowIndex
         , 	colIndex
         , 	value)
}


def static "com.kms.katalon.keyword.excel.ExcelKeywords.getColumnsByIndex"(
    	Sheet sheet	
     , 	java.util.List<java.lang.Integer> columnIndexes	) {
    (new com.kms.katalon.keyword.excel.ExcelKeywords()).getColumnsByIndex(
        	sheet
         , 	columnIndexes)
}


def static "com.kms.katalon.keyword.excel.ExcelKeywords.getRowIndexByCellContent"(
    	Sheet sheet	
     , 	String cellContent	
     , 	int columnIdxForCell	) {
    (new com.kms.katalon.keyword.excel.ExcelKeywords()).getRowIndexByCellContent(
        	sheet
         , 	cellContent
         , 	columnIdxForCell)
}


def static "com.kms.katalon.keyword.excel.ExcelKeywords.getCellValueByAddress"(
    	Sheet sheet	
     , 	String cellAddress	) {
    (new com.kms.katalon.keyword.excel.ExcelKeywords()).getCellValueByAddress(
        	sheet
         , 	cellAddress)
}


def static "com.kms.katalon.keyword.excel.ExcelKeywords.getSheetNames"(
    	Workbook workbook	) {
    (new com.kms.katalon.keyword.excel.ExcelKeywords()).getSheetNames(
        	workbook)
}

/**
	 * @param tag (String) The tag element used to find the target element.
	 * @param to (TestObject) constructed TestObject
	 * @return (TestObject) The constructed TestObject.
	 */
def static "generalFunc.AllgenralFunc.makeToTag"(
    	String tag	
     , 	TestObject to	) {
    (new generalFunc.AllgenralFunc()).makeToTag(
        	tag
         , 	to)
}

/**
	 * @param text (String) The text used to find the target element.
	 * @param to (TestObject) constructed TestObject
	 * @return (TestObject) The constructed TestObject.
	 */
def static "generalFunc.AllgenralFunc.makeToText"(
    	String text	
     , 	TestObject to	) {
    (new generalFunc.AllgenralFunc()).makeToText(
        	text
         , 	to)
}

/**
	 * @param css (String) The class name used to find the target element.
	 * @param to (TestObject) constructed TestObject
	 * @return (TestObject) The constructed TestObject.
	 */
def static "generalFunc.AllgenralFunc.makeToCssCls"(
    	String css	
     , 	TestObject to	) {
    (new generalFunc.AllgenralFunc()).makeToCssCls(
        	css
         , 	to)
}

/**
	 * @param css (String) The id name used to find the target element.
	 * @param to (TestObject) constructed TestObject
	 * @return (TestObject) The constructed TestObject.
	 */
def static "generalFunc.AllgenralFunc.makeToCssId"(
    	String css	
     , 	TestObject to	) {
    (new generalFunc.AllgenralFunc()).makeToCssId(
        	css
         , 	to)
}

/**
	 * @param data (String) The data attribute used to find the target element.(ex: for,data-value,title)
	 * @param val (String) The value of data attribute used to find the target element.
	 * @param to (TestObject) constructed TestObject
	 * @return (TestObject) The constructed TestObject.
	 */
def static "generalFunc.AllgenralFunc.makeToDataVal"(
    	String data	
     , 	String val	
     , 	TestObject to	) {
    (new generalFunc.AllgenralFunc()).makeToDataVal(
        	data
         , 	val
         , 	to)
}


def static "generalFunc.AllgenralFunc.makeToXpath"(
    	String xpath	
     , 	TestObject to	) {
    (new generalFunc.AllgenralFunc()).makeToXpath(
        	xpath
         , 	to)
}

/**
	 * Wrapper function for Katalon-compatible Test Object construct functions
	 * @param tag (String) The tag element used to find the target element.
	 * @param text (String) The text used to find the target element.
	 * @param cls (String) The class name used to find the target element.
	 * @param id (String) The id name used to find the target element.
	 * @param data, val (String, String) The data attribute and it's value used to find the target element.
	 * @return (TestObject) The constructed TestObject.
	 */
def static "generalFunc.AllgenralFunc.makeTestObject"(
    	String tag	
     , 	String text	
     , 	String cls	
     , 	String id	
     , 	String data	
     , 	String val	
     , 	String xpath	) {
    (new generalFunc.AllgenralFunc()).makeTestObject(
        	tag
         , 	text
         , 	cls
         , 	id
         , 	data
         , 	val
         , 	xpath)
}


def static "generalFunc.AllgenralFunc.shortDelay"() {
    (new generalFunc.AllgenralFunc()).shortDelay()
}


def static "generalFunc.AllgenralFunc.waitTill"(
    	Object waiT	) {
    (new generalFunc.AllgenralFunc()).waitTill(
        	waiT)
}


def static "generalFunc.AllgenralFunc.longDelay"() {
    (new generalFunc.AllgenralFunc()).longDelay()
}


def static "generalFunc.AllgenralFunc.longestDelay"() {
    (new generalFunc.AllgenralFunc()).longestDelay()
}


def static "generalFunc.AllgenralFunc.warningForHigherCols"() {
    (new generalFunc.AllgenralFunc()).warningForHigherCols()
}


def static "generalFunc.AllgenralFunc.licenseExpiryOK"() {
    (new generalFunc.AllgenralFunc()).licenseExpiryOK()
}


def static "generalFunc.AllgenralFunc.logTestCaseID"(
    	String TestCaseID	) {
    (new generalFunc.AllgenralFunc()).logTestCaseID(
        	TestCaseID)
}


def static "generalFunc.AllgenralFunc.alertHandling"() {
    (new generalFunc.AllgenralFunc()).alertHandling()
}


def static "generalFunc.AllgenralFunc.ScrollTo"(
    	Object obj	
     , 	Object timeout	) {
    (new generalFunc.AllgenralFunc()).ScrollTo(
        	obj
         , 	timeout)
}


def static "generalFunc.AllgenralFunc.clickUsingJS"(
    	TestObject to	
     , 	int timeout	) {
    (new generalFunc.AllgenralFunc()).clickUsingJS(
        	to
         , 	timeout)
}


def static "generalFunc.AllgenralFunc.clickUserLoginDropDown"() {
    (new generalFunc.AllgenralFunc()).clickUserLoginDropDown()
}


def static "generalFunc.AllgenralFunc.kanvasLogo"() {
    (new generalFunc.AllgenralFunc()).kanvasLogo()
}


def static "generalFunc.AllgenralFunc.warningMsgChk"() {
    (new generalFunc.AllgenralFunc()).warningMsgChk()
}


def static "generalFunc.AllgenralFunc.SwitchtoWorkspace"() {
    (new generalFunc.AllgenralFunc()).SwitchtoWorkspace()
}


def static "generalFunc.AllgenralFunc.startFresh"(
    	String startFresh	) {
    (new generalFunc.AllgenralFunc()).startFresh(
        	startFresh)
}


def static "generalFunc.AllgenralFunc.fullScrn"() {
    (new generalFunc.AllgenralFunc()).fullScrn()
}


def static "generalFunc.AllgenralFunc.sideMenuBar"() {
    (new generalFunc.AllgenralFunc()).sideMenuBar()
}


def static "com.BB.layoutFunctions.loadTemplate"(
    	String tempName	) {
    (new com.BB.layoutFunctions()).loadTemplate(
        	tempName)
}

/**
	 * @param tag (String) The tag element used to find the target element.
	 * @param to (TestObject) constructed TestObject
	 * @return (TestObject) The constructed TestObject.
	 */
def static "com.BB.allFunctions.makeToTag"(
    	String tag	
     , 	TestObject to	) {
    (new com.BB.allFunctions()).makeToTag(
        	tag
         , 	to)
}

/**
	 * @param text (String) The text used to find the target element.
	 * @param to (TestObject) constructed TestObject
	 * @return (TestObject) The constructed TestObject.
	 */
def static "com.BB.allFunctions.makeToText"(
    	String text	
     , 	TestObject to	) {
    (new com.BB.allFunctions()).makeToText(
        	text
         , 	to)
}

/**
	 * @param css (String) The class name used to find the target element.
	 * @param to (TestObject) constructed TestObject
	 * @return (TestObject) The constructed TestObject.
	 */
def static "com.BB.allFunctions.makeToCssCls"(
    	String css	
     , 	TestObject to	) {
    (new com.BB.allFunctions()).makeToCssCls(
        	css
         , 	to)
}

/**
	 * @param css (String) The id name used to find the target element.
	 * @param to (TestObject) constructed TestObject
	 * @return (TestObject) The constructed TestObject.
	 */
def static "com.BB.allFunctions.makeToCssId"(
    	String css	
     , 	TestObject to	) {
    (new com.BB.allFunctions()).makeToCssId(
        	css
         , 	to)
}

/**
	 * @param data (String) The data attribute used to find the target element.(ex: for,data-value,title)
	 * @param val (String) The value of data attribute used to find the target element.
	 * @param to (TestObject) constructed TestObject
	 * @return (TestObject) The constructed TestObject.
	 */
def static "com.BB.allFunctions.makeToDataVal"(
    	String data	
     , 	String val	
     , 	TestObject to	) {
    (new com.BB.allFunctions()).makeToDataVal(
        	data
         , 	val
         , 	to)
}

/**
	 * @param xpath (String) The data attribute used to find the target element
	 * @param to (TestObject) constructed TestObject
	 * @return (TestObject) The constructed TestObject.
	 */
def static "com.BB.allFunctions.makeToXpath"(
    	String xpath	
     , 	TestObject to	) {
    (new com.BB.allFunctions()).makeToXpath(
        	xpath
         , 	to)
}

/**
	 * Wrapper function for Katalon-compatible Test Object construct functions
	 * @param tag (String) The tag element used to find the target element.
	 * @param text (String) The text used to find the target element.
	 * @param cls (String) The class name used to find the target element.
	 * @param id (String) The id name used to find the target element.
	 * @param data, val (String, String) The data attribute and it's value used to find the target element.
	 * @param xpath (String) The xpath used to find the target element.
	 * @return (TestObject) The constructed TestObject.
	 */
def static "com.BB.allFunctions.makeTestObject"(
    	String tag	
     , 	String text	
     , 	String cls	
     , 	String id	
     , 	String data	
     , 	String val	
     , 	String xpath	) {
    (new com.BB.allFunctions()).makeTestObject(
        	tag
         , 	text
         , 	cls
         , 	id
         , 	data
         , 	val
         , 	xpath)
}

/** **************************** General Functions ******************** */
def static "com.BB.allFunctions.ScrollTo"(
    	Object obj	
     , 	Object timeout	) {
    (new com.BB.allFunctions()).ScrollTo(
        	obj
         , 	timeout)
}


def static "com.BB.allFunctions.clickUsingJS"(
    	TestObject to	
     , 	int timeout	) {
    (new com.BB.allFunctions()).clickUsingJS(
        	to
         , 	timeout)
}

/** **************************** Main Functions ******************** */
def static "com.BB.allFunctions.ResetAllFlts"() {
    (new com.BB.allFunctions()).ResetAllFlts()
}


def static "com.BB.allFunctions.FilterApplyBtn"() {
    (new com.BB.allFunctions()).FilterApplyBtn()
}


def static "com.BB.allFunctions.ClickInfoBtn"() {
    (new com.BB.allFunctions()).ClickInfoBtn()
}

/** **************************** Validation Functions ******************** */
def static "com.BB.allFunctions.actualItemCntGrp"(
    	String expected	) {
    (new com.BB.allFunctions()).actualItemCntGrp(
        	expected)
}


def static "com.BB.allFunctions.actualItemCntFlt"(
    	String expected	) {
    (new com.BB.allFunctions()).actualItemCntFlt(
        	expected)
}


def static "com.BB.allFunctions.CompareItemCnt"(
    	String expected	
     , 	String groupByAttrName	) {
    (new com.BB.allFunctions()).CompareItemCnt(
        	expected
         , 	groupByAttrName)
}


def static "com.BB.allFunctions.CompareTooltipInfo"(
    	Object tiexpected	
     , 	Object tiactual	) {
    (new com.BB.allFunctions()).CompareTooltipInfo(
        	tiexpected
         , 	tiactual)
}


def static "com.BB.allFunctions.CompareStatsSummary"(
    	Object tiexpected	
     , 	Object tiactual	) {
    (new com.BB.allFunctions()).CompareStatsSummary(
        	tiexpected
         , 	tiactual)
}


def static "com.BB.allFunctions.Stndardcnt"() {
    (new com.BB.allFunctions()).Stndardcnt()
}


def static "com.BB.allFunctions.tabVsStdcnt"() {
    (new com.BB.allFunctions()).tabVsStdcnt()
}


def static "com.BB.allFunctions.getActualItemCntG"() {
    (new com.BB.allFunctions()).getActualItemCntG()
}

/** **************************** Limit Functions ******************** */
def static "com.BB.allFunctions.setItemLimit"(
    	Object limit	) {
    (new com.BB.allFunctions()).setItemLimit(
        	limit)
}

/** **************************** Sort Functions ******************** */
def static "com.BB.allFunctions.sortDone"(
    	String sortAttrName	
     , 	String statsAttrName	) {
    (new com.BB.allFunctions()).sortDone(
        	sortAttrName
         , 	statsAttrName)
}

/** **************************** ShowData Functions ******************** */
def static "com.BB.allFunctions.enableShowData"() {
    (new com.BB.allFunctions()).enableShowData()
}


def static "com.BB.allFunctions.enableHideData"() {
    (new com.BB.allFunctions()).enableHideData()
}

/** **************************** Hierarchy Functions ******************** */
def static "com.BB.allFunctions.HierarchyBtn"(
    	String hAttrNames	) {
    (new com.BB.allFunctions()).HierarchyBtn(
        	hAttrNames)
}


def static "com.BB.allFunctions.HierarchySave"() {
    (new com.BB.allFunctions()).HierarchySave()
}

/** **************************** Workspace Functions ******************** */
def static "com.BB.allFunctions.SaveWorkspace"(
    	Object name	) {
    (new com.BB.allFunctions()).SaveWorkspace(
        	name)
}


def static "com.BB.allFunctions.SwitchtoWorkspace"() {
    (new com.BB.allFunctions()).SwitchtoWorkspace()
}

/** **************************** Tabular Functions ******************** */
def static "com.BB.allFunctions.TabularItemCount"() {
    (new com.BB.allFunctions()).TabularItemCount()
}

/** **************************** Filter Functions ******************** */
def static "com.BB.allFunctions.SetMsrVal"(
    	Object abj	
     , 	Object obj	
     , 	Object timeout	
     , 	Object value	) {
    (new com.BB.allFunctions()).SetMsrVal(
        	abj
         , 	obj
         , 	timeout
         , 	value)
}


def static "com.BB.allFunctions.clickAttrVals"(
    	String vals	
     , 	String vSep	) {
    (new com.BB.allFunctions()).clickAttrVals(
        	vals
         , 	vSep)
}


def static "com.BB.allFunctions.selAttrNdVals"(
    	String attrNames	
     , 	String attrVals	
     , 	String nSep	
     , 	String vSep	
     , 	String attrClass	) {
    (new com.BB.allFunctions()).selAttrNdVals(
        	attrNames
         , 	attrVals
         , 	nSep
         , 	vSep
         , 	attrClass)
}

/** ****************************  Group Functions ******************** */
def static "com.BB.allFunctions.clickGrpAttrs"(
    	String groupByAttrName	
     , 	String nSep	) {
    (new com.BB.allFunctions()).clickGrpAttrs(
        	groupByAttrName
         , 	nSep)
}


def static "standardFunc.AllstandardFunc.switchToStandard"() {
    (new standardFunc.AllstandardFunc()).switchToStandard()
}


def static "standardFunc.AllstandardFunc.switchToLayoutFromStd"() {
    (new standardFunc.AllstandardFunc()).switchToLayoutFromStd()
}


def static "standardFunc.AllstandardFunc.ResetAllFlts"() {
    (new standardFunc.AllstandardFunc()).ResetAllFlts()
}


def static "standardFunc.AllstandardFunc.ClickInfoBtn"() {
    (new standardFunc.AllstandardFunc()).ClickInfoBtn()
}


def static "standardFunc.AllstandardFunc.CompareTooltipInfo"(
    	Object expectedToolTipInfo	) {
    (new standardFunc.AllstandardFunc()).CompareTooltipInfo(
        	expectedToolTipInfo)
}


def static "standardFunc.AllstandardFunc.validateMsriw"(
    	String miwitemID	
     , 	String msrNM	
     , 	String expmsrVals	
     , 	String nSep	
     , 	String vSep	) {
    (new standardFunc.AllstandardFunc()).validateMsriw(
        	miwitemID
         , 	msrNM
         , 	expmsrVals
         , 	nSep
         , 	vSep)
}


def static "standardFunc.AllstandardFunc.validateAttriw"(
    	String aiwitemID	
     , 	String attrNMiw	
     , 	String expattrVals	
     , 	String nSep	
     , 	String vSep	) {
    (new standardFunc.AllstandardFunc()).validateAttriw(
        	aiwitemID
         , 	attrNMiw
         , 	expattrVals
         , 	nSep
         , 	vSep)
}


def static "standardFunc.AllstandardFunc.ClickonItemWin"(
    	String itemID	
     , 	String msrNM	
     , 	String expmsrVals	
     , 	String nSep	
     , 	String vSep	) {
    (new standardFunc.AllstandardFunc()).ClickonItemWin(
        	itemID
         , 	msrNM
         , 	expmsrVals
         , 	nSep
         , 	vSep)
}


def static "standardFunc.AllstandardFunc.CompareMsrVals"(
    	String msrNM	
     , 	String expmsrVals	
     , 	String vSep	) {
    (new standardFunc.AllstandardFunc()).CompareMsrVals(
        	msrNM
         , 	expmsrVals
         , 	vSep)
}


def static "standardFunc.AllstandardFunc.doSearch"(
    	String searchStatus	
     , 	String searchKeyword	) {
    (new standardFunc.AllstandardFunc()).doSearch(
        	searchStatus
         , 	searchKeyword)
}


def static "standardFunc.AllstandardFunc.FilterApplyBtn"() {
    (new standardFunc.AllstandardFunc()).FilterApplyBtn()
}


def static "standardFunc.AllstandardFunc.clickAttrVals"(
    	String vals	
     , 	String vSep	) {
    (new standardFunc.AllstandardFunc()).clickAttrVals(
        	vals
         , 	vSep)
}


def static "standardFunc.AllstandardFunc.selAttrNdVals"(
    	String attrNames	
     , 	String attrVals	
     , 	String nSep	
     , 	String vSep	) {
    (new standardFunc.AllstandardFunc()).selAttrNdVals(
        	attrNames
         , 	attrVals
         , 	nSep
         , 	vSep)
}


def static "standardFunc.AllstandardFunc.clickOnSelAllVals"(
    	String attrNameSelAllVals	
     , 	String nSep	) {
    (new standardFunc.AllstandardFunc()).clickOnSelAllVals(
        	attrNameSelAllVals
         , 	nSep)
}


def static "standardFunc.AllstandardFunc.resetAttributeNM"(
    	String attrNMReset	
     , 	String nSep	) {
    (new standardFunc.AllstandardFunc()).resetAttributeNM(
        	attrNMReset
         , 	nSep)
}


def static "standardFunc.AllstandardFunc.resetTTag"(
    	String rTTag	
     , 	String nSep	) {
    (new standardFunc.AllstandardFunc()).resetTTag(
        	rTTag
         , 	nSep)
}


def static "standardFunc.AllstandardFunc.searchAttrNdFlt"(
    	String sAttrNM	
     , 	String attrVals	
     , 	String nSep	
     , 	String vSep	) {
    (new standardFunc.AllstandardFunc()).searchAttrNdFlt(
        	sAttrNM
         , 	attrVals
         , 	nSep
         , 	vSep)
}


def static "standardFunc.AllstandardFunc.searchAttrVals"(
    	String srchAttrNM	
     , 	String srchattrVals	
     , 	String srchvalsStatus	
     , 	String nSep	
     , 	String vSep	) {
    (new standardFunc.AllstandardFunc()).searchAttrVals(
        	srchAttrNM
         , 	srchattrVals
         , 	srchvalsStatus
         , 	nSep
         , 	vSep)
}


def static "standardFunc.AllstandardFunc.deselAttrVals"(
    	String SresetAttrNM	
     , 	String SresetVals	
     , 	String nSep	
     , 	String vSep	) {
    (new standardFunc.AllstandardFunc()).deselAttrVals(
        	SresetAttrNM
         , 	SresetVals
         , 	nSep
         , 	vSep)
}


def static "standardFunc.AllstandardFunc.searchMsrNdFlt"(
    	String sMsrNM	
     , 	String minVal	
     , 	String maxVal	
     , 	String nSep	
     , 	String vSep	) {
    (new standardFunc.AllstandardFunc()).searchMsrNdFlt(
        	sMsrNM
         , 	minVal
         , 	maxVal
         , 	nSep
         , 	vSep)
}


def static "standardFunc.AllstandardFunc.selHAttrNdVals"(
    	String hAttrNames	
     , 	String hAttrVals	
     , 	String nSep	
     , 	String vSep	) {
    (new standardFunc.AllstandardFunc()).selHAttrNdVals(
        	hAttrNames
         , 	hAttrVals
         , 	nSep
         , 	vSep)
}


def static "standardFunc.AllstandardFunc.SetMsrValbyFunc"(
    	String msrNames	
     , 	String minVal	
     , 	String maxVal	
     , 	String nSep	) {
    (new standardFunc.AllstandardFunc()).SetMsrValbyFunc(
        	msrNames
         , 	minVal
         , 	maxVal
         , 	nSep)
}


def static "standardFunc.AllstandardFunc.setTextTag"(
    	String TextTag	
     , 	String nSep	) {
    (new standardFunc.AllstandardFunc()).setTextTag(
        	TextTag
         , 	nSep)
}


def static "standardFunc.AllstandardFunc.setColorTag"(
    	String clrGrpNM	
     , 	String ColorTag	
     , 	String nSep	
     , 	String vSep	) {
    (new standardFunc.AllstandardFunc()).setColorTag(
        	clrGrpNM
         , 	ColorTag
         , 	nSep
         , 	vSep)
}


def static "standardFunc.AllstandardFunc.chooseClr"(
    	String clrName	
     , 	String vSep	) {
    (new standardFunc.AllstandardFunc()).chooseClr(
        	clrName
         , 	vSep)
}


def static "standardFunc.AllstandardFunc.setIconTag"(
    	String iconGrpNM	
     , 	String IconTag	
     , 	String nSep	
     , 	String vSep	) {
    (new standardFunc.AllstandardFunc()).setIconTag(
        	iconGrpNM
         , 	IconTag
         , 	nSep
         , 	vSep)
}


def static "standardFunc.AllstandardFunc.clickGrpAttrs"(
    	String groupByAttrName	
     , 	String nSep	) {
    (new standardFunc.AllstandardFunc()).clickGrpAttrs(
        	groupByAttrName
         , 	nSep)
}


def static "standardFunc.AllstandardFunc.clickGrpTextTags"(
    	String grpByTextTag	) {
    (new standardFunc.AllstandardFunc()).clickGrpTextTags(
        	grpByTextTag)
}


def static "standardFunc.AllstandardFunc.clickGrpClrTags"(
    	String grpByClrTag	) {
    (new standardFunc.AllstandardFunc()).clickGrpClrTags(
        	grpByClrTag)
}


def static "standardFunc.AllstandardFunc.sortDone"(
    	String sortAttrName	
     , 	String statsAttrName	) {
    (new standardFunc.AllstandardFunc()).sortDone(
        	sortAttrName
         , 	statsAttrName)
}


def static "standardFunc.AllstandardFunc.doneSortBtn"() {
    (new standardFunc.AllstandardFunc()).doneSortBtn()
}


def static "standardFunc.AllstandardFunc.doSort"(
    	String sortAttrName	
     , 	String attrStatus	
     , 	String nSep	
     , 	String vSep	) {
    (new standardFunc.AllstandardFunc()).doSort(
        	sortAttrName
         , 	attrStatus
         , 	nSep
         , 	vSep)
}


def static "standardFunc.AllstandardFunc.doStats"(
    	String statsAttrName	
     , 	String nSep	) {
    (new standardFunc.AllstandardFunc()).doStats(
        	statsAttrName
         , 	nSep)
}


def static "standardFunc.AllstandardFunc.mDoSort"(
    	String sortAttrName	
     , 	String attrStatus	
     , 	String vSep	) {
    (new standardFunc.AllstandardFunc()).mDoSort(
        	sortAttrName
         , 	attrStatus
         , 	vSep)
}


def static "standardFunc.AllstandardFunc.DogroupSort"(
    	String grpsortAttrName	
     , 	String grpattrStatus	
     , 	String aggrVal	
     , 	String vSep	
     , 	String nSep	) {
    (new standardFunc.AllstandardFunc()).DogroupSort(
        	grpsortAttrName
         , 	grpattrStatus
         , 	aggrVal
         , 	vSep
         , 	nSep)
}


def static "standardFunc.AllstandardFunc.groupmDoSort"(
    	String grpsortAttrName	
     , 	String grpattrStatus	
     , 	String vSep	) {
    (new standardFunc.AllstandardFunc()).groupmDoSort(
        	grpsortAttrName
         , 	grpattrStatus
         , 	vSep)
}


def static "standardFunc.AllstandardFunc.grpSortAggr"(
    	String grpsortAttrName	
     , 	String aggrVal	) {
    (new standardFunc.AllstandardFunc()).grpSortAggr(
        	grpsortAttrName
         , 	aggrVal)
}


def static "standardFunc.AllstandardFunc.setItemLimit"(
    	Object limit	) {
    (new standardFunc.AllstandardFunc()).setItemLimit(
        	limit)
}


def static "standardFunc.AllstandardFunc.enableShowData"() {
    (new standardFunc.AllstandardFunc()).enableShowData()
}


def static "standardFunc.AllstandardFunc.enableHideData"() {
    (new standardFunc.AllstandardFunc()).enableHideData()
}


def static "standardFunc.AllstandardFunc.doShowData"(
    	String showDataAttrName	
     , 	String nSep	) {
    (new standardFunc.AllstandardFunc()).doShowData(
        	showDataAttrName
         , 	nSep)
}


def static "standardFunc.AllstandardFunc.saveShowData"() {
    (new standardFunc.AllstandardFunc()).saveShowData()
}


def static "standardFunc.AllstandardFunc.compareShowData"(
    	String sdItemID	
     , 	String sdVals	
     , 	String nSep	
     , 	String vSep	) {
    (new standardFunc.AllstandardFunc()).compareShowData(
        	sdItemID
         , 	sdVals
         , 	nSep
         , 	vSep)
}


def static "standardFunc.AllstandardFunc.HierarchyBtn"() {
    (new standardFunc.AllstandardFunc()).HierarchyBtn()
}


def static "standardFunc.AllstandardFunc.HierarchySave"() {
    (new standardFunc.AllstandardFunc()).HierarchySave()
}


def static "standardFunc.AllstandardFunc.CompareItemCnt"(
    	String expected	) {
    (new standardFunc.AllstandardFunc()).CompareItemCnt(
        	expected)
}


def static "standardFunc.AllstandardFunc.actualItemCntFlt"(
    	String expected	) {
    (new standardFunc.AllstandardFunc()).actualItemCntFlt(
        	expected)
}


def static "standardFunc.AllstandardFunc.actualItemCntGrp"(
    	String expected	) {
    (new standardFunc.AllstandardFunc()).actualItemCntGrp(
        	expected)
}


def static "standardFunc.AllstandardFunc.CompareStatsSummary"(
    	Object tiexpected	
     , 	Object tiactual	) {
    (new standardFunc.AllstandardFunc()).CompareStatsSummary(
        	tiexpected
         , 	tiactual)
}


def static "standardFunc.AllstandardFunc.Stndardcnt"() {
    (new standardFunc.AllstandardFunc()).Stndardcnt()
}


def static "standardFunc.AllstandardFunc.tabVsStdcnt"() {
    (new standardFunc.AllstandardFunc()).tabVsStdcnt()
}


def static "standardFunc.AllstandardFunc.getActualItemCntG"() {
    (new standardFunc.AllstandardFunc()).getActualItemCntG()
}


def static "standardFunc.AllstandardFunc.saveWS"(
    	Object workspaceNameS	) {
    (new standardFunc.AllstandardFunc()).saveWS(
        	workspaceNameS)
}


def static "standardFunc.AllstandardFunc.SaveWorkspace"(
    	Object wsName	
     , 	String keepShareStngs	) {
    (new standardFunc.AllstandardFunc()).SaveWorkspace(
        	wsName
         , 	keepShareStngs)
}


def static "standardFunc.AllstandardFunc.loadWorkspace"(
    	String workspaceName	
     , 	String nSep	) {
    (new standardFunc.AllstandardFunc()).loadWorkspace(
        	workspaceName
         , 	nSep)
}


def static "standardFunc.AllstandardFunc.restoreWorkspace"(
    	String restoreWS	
     , 	String nSep	) {
    (new standardFunc.AllstandardFunc()).restoreWorkspace(
        	restoreWS
         , 	nSep)
}


def static "standardFunc.AllstandardFunc.shareWS"(
    	String shareStatus	
     , 	String shareUser	
     , 	String vSep	) {
    (new standardFunc.AllstandardFunc()).shareWS(
        	shareStatus
         , 	shareUser
         , 	vSep)
}


def static "standardFunc.AllstandardFunc.clickOnShareIcon"(
    	String wsNameShare	
     , 	String nSep	) {
    (new standardFunc.AllstandardFunc()).clickOnShareIcon(
        	wsNameShare
         , 	nSep)
}


def static "standardFunc.AllstandardFunc.doShareWS"(
    	String wsNameShare	
     , 	String shareStatus	
     , 	String shareUser	
     , 	String vSep	
     , 	String nSep	) {
    (new standardFunc.AllstandardFunc()).doShareWS(
        	wsNameShare
         , 	shareStatus
         , 	shareUser
         , 	vSep
         , 	nSep)
}


def static "standardFunc.AllstandardFunc.myWSTab"() {
    (new standardFunc.AllstandardFunc()).myWSTab()
}


def static "standardFunc.AllstandardFunc.sharedWSTab"() {
    (new standardFunc.AllstandardFunc()).sharedWSTab()
}


def static "standardFunc.AllstandardFunc.switchToTabular"() {
    (new standardFunc.AllstandardFunc()).switchToTabular()
}


def static "standardFunc.AllstandardFunc.exportFrmSM"(
    	String ESMfileNM	
     , 	String ESMcmnts	) {
    (new standardFunc.AllstandardFunc()).exportFrmSM(
        	ESMfileNM
         , 	ESMcmnts)
}


def static "standardFunc.AllstandardFunc.downloadIcon"() {
    (new standardFunc.AllstandardFunc()).downloadIcon()
}


def static "standardFunc.AllstandardFunc.doEditAttrVal"(
    	String EdititemID	
     , 	String EAttrMsrNM	
     , 	String newEditVal	) {
    (new standardFunc.AllstandardFunc()).doEditAttrVal(
        	EdititemID
         , 	EAttrMsrNM
         , 	newEditVal)
}


def static "standardFunc.AllstandardFunc.loadmoreBtn"() {
    (new standardFunc.AllstandardFunc()).loadmoreBtn()
}


def static "standardFunc.AllstandardFunc.restoreLastWS"() {
    (new standardFunc.AllstandardFunc()).restoreLastWS()
}


def static "com.test.demo.UploadCustomFunctions.uploadfile"(
    	TestObject to	
     , 	String filePath	) {
    (new com.test.demo.UploadCustomFunctions()).uploadfile(
        	to
         , 	filePath)
}


def static "com.test.demo.sortfunctions.SortOrderAscend"(
    	TestObject msrDes	
     , 	TestObject msrAsc	
     , 	TestObject msrDis	) {
    (new com.test.demo.sortfunctions()).SortOrderAscend(
        	msrDes
         , 	msrAsc
         , 	msrDis)
}


def static "com.test.demo.sortfunctions.SortOrderDescend"(
    	TestObject msrDes	
     , 	TestObject msrAsc	
     , 	TestObject msrDis	) {
    (new com.test.demo.sortfunctions()).SortOrderDescend(
        	msrDes
         , 	msrAsc
         , 	msrDis)
}


def static "com.test.demo.sortfunctions.SortOrderDisable"(
    	TestObject msrDes	
     , 	TestObject msrAsc	
     , 	TestObject msrDis	) {
    (new com.test.demo.sortfunctions()).SortOrderDisable(
        	msrDes
         , 	msrAsc
         , 	msrDis)
}


def static "dashboardFunc.AlldashboardFunc.fatalErrChk"() {
    (new dashboardFunc.AlldashboardFunc()).fatalErrChk()
}


def static "dashboardFunc.AlldashboardFunc.downloadExportFileTR15"(
    	String exportFileName	) {
    (new dashboardFunc.AlldashboardFunc()).downloadExportFileTR15(
        	exportFileName)
}


def static "dashboardFunc.AlldashboardFunc.exportTabularFromDashboard"(
    	String exportFileName	) {
    (new dashboardFunc.AlldashboardFunc()).exportTabularFromDashboard(
        	exportFileName)
}


def static "com.BB.Login.kanvasLoginU"(
    	String url	
     , 	String userName	
     , 	String pwd	) {
    (new com.BB.Login()).kanvasLoginU(
        	url
         , 	userName
         , 	pwd)
}


def static "com.BB.Login.kanvasRelogin"(
    	String url	
     , 	String userName	
     , 	String pwd	) {
    (new com.BB.Login()).kanvasRelogin(
        	url
         , 	userName
         , 	pwd)
}


def static "com.BB.Login.kanvasLogin"(
    	String url	
     , 	String userName	
     , 	String pwd	) {
    (new com.BB.Login()).kanvasLogin(
        	url
         , 	userName
         , 	pwd)
}


def static "com.BB.Login.KLoginBenjaminuser43"() {
    (new com.BB.Login()).KLoginBenjaminuser43()
}


def static "com.BB.Login.KproductionLogin"() {
    (new com.BB.Login()).KproductionLogin()
}


def static "com.BB.Login.KlocalLogin"() {
    (new com.BB.Login()).KlocalLogin()
}


def static "com.test.demo.MySelectionCustomFunctions.ResetAllFlts"() {
    (new com.test.demo.MySelectionCustomFunctions()).ResetAllFlts()
}


def static "com.test.demo.MySelectionCustomFunctions.HierarchyBtn"() {
    (new com.test.demo.MySelectionCustomFunctions()).HierarchyBtn()
}


def static "com.test.demo.MySelectionCustomFunctions.HierarchySave"() {
    (new com.test.demo.MySelectionCustomFunctions()).HierarchySave()
}


def static "com.test.demo.MySelectionCustomFunctions.FilterApplyBtn"() {
    (new com.test.demo.MySelectionCustomFunctions()).FilterApplyBtn()
}


def static "com.test.demo.MySelectionCustomFunctions.ScrollTo"(
    	Object obj	
     , 	Object timeout	) {
    (new com.test.demo.MySelectionCustomFunctions()).ScrollTo(
        	obj
         , 	timeout)
}


def static "com.test.demo.MySelectionCustomFunctions.CompareItemCnt"(
    	Object expected	
     , 	Object actual	) {
    (new com.test.demo.MySelectionCustomFunctions()).CompareItemCnt(
        	expected
         , 	actual)
}


def static "com.test.demo.MySelectionCustomFunctions.CompareTooltipInfo"(
    	Object tiexpected	
     , 	Object tiactual	) {
    (new com.test.demo.MySelectionCustomFunctions()).CompareTooltipInfo(
        	tiexpected
         , 	tiactual)
}


def static "com.test.demo.MySelectionCustomFunctions.CompareStatsSummary"(
    	Object tiexpected	
     , 	Object tiactual	) {
    (new com.test.demo.MySelectionCustomFunctions()).CompareStatsSummary(
        	tiexpected
         , 	tiactual)
}


def static "com.test.demo.MySelectionCustomFunctions.clickUsingJS"(
    	TestObject to	
     , 	int timeout	) {
    (new com.test.demo.MySelectionCustomFunctions()).clickUsingJS(
        	to
         , 	timeout)
}


def static "com.test.demo.MySelectionCustomFunctions.ClickInfoBtn"() {
    (new com.test.demo.MySelectionCustomFunctions()).ClickInfoBtn()
}


def static "com.test.demo.MySelectionCustomFunctions.SaveWorkspace"(
    	Object name	) {
    (new com.test.demo.MySelectionCustomFunctions()).SaveWorkspace(
        	name)
}


def static "com.test.demo.MySelectionCustomFunctions.SetMsrVal"(
    	Object abj	
     , 	Object obj	
     , 	Object timeout	
     , 	Object value	) {
    (new com.test.demo.MySelectionCustomFunctions()).SetMsrVal(
        	abj
         , 	obj
         , 	timeout
         , 	value)
}


def static "com.test.demo.MySelectionCustomFunctions.SwitchtoWorkspace"() {
    (new com.test.demo.MySelectionCustomFunctions()).SwitchtoWorkspace()
}


def static "com.test.demo.MySelectionCustomFunctions.SortOrderAscend"(
    	TestObject msrDes	
     , 	TestObject msrAsc	
     , 	TestObject msrDis	) {
    (new com.test.demo.MySelectionCustomFunctions()).SortOrderAscend(
        	msrDes
         , 	msrAsc
         , 	msrDis)
}


def static "com.test.demo.MySelectionCustomFunctions.SortOrderDescend"(
    	TestObject msrDes	
     , 	TestObject msrAsc	
     , 	TestObject msrDis	) {
    (new com.test.demo.MySelectionCustomFunctions()).SortOrderDescend(
        	msrDes
         , 	msrAsc
         , 	msrDis)
}


def static "com.test.demo.MySelectionCustomFunctions.SortOrderDisable"(
    	TestObject msrDes	
     , 	TestObject msrAsc	
     , 	TestObject msrDis	) {
    (new com.test.demo.MySelectionCustomFunctions()).SortOrderDisable(
        	msrDes
         , 	msrAsc
         , 	msrDis)
}


def static "com.test.demo.MySelectionCustomFunctions.TabularItemCount"(
    	TestObject obj1	
     , 	TestObject obj2	) {
    (new com.test.demo.MySelectionCustomFunctions()).TabularItemCount(
        	obj1
         , 	obj2)
}


def static "tabularFunc.AlltabularFunc.switchToLayoutFromTabular"() {
    (new tabularFunc.AlltabularFunc()).switchToLayoutFromTabular()
}


def static "tabularFunc.AlltabularFunc.colSubTotal15"(
    	String colSubTotal	
     , 	String cFieldnm	
     , 	String vSep	) {
    (new tabularFunc.AlltabularFunc()).colSubTotal15(
        	colSubTotal
         , 	cFieldnm
         , 	vSep)
}


def static "tabularFunc.AlltabularFunc.TabularItemCount"() {
    (new tabularFunc.AlltabularFunc()).TabularItemCount()
}


def static "tabularFunc.AlltabularFunc.compareTabularR15"(
    	String exportFileName	
     , 	String expectedPath	
     , 	String actualPath	) {
    (new tabularFunc.AlltabularFunc()).compareTabularR15(
        	exportFileName
         , 	expectedPath
         , 	actualPath)
}


def static "tabularFunc.AlltabularFunc.compareTabularR14"(
    	String expectedPath	
     , 	String actualPath	) {
    (new tabularFunc.AlltabularFunc()).compareTabularR14(
        	expectedPath
         , 	actualPath)
}


def static "tabularFunc.AlltabularFunc.exportAllTabularR14"(
    	String exportFileName	) {
    (new tabularFunc.AlltabularFunc()).exportAllTabularR14(
        	exportFileName)
}


def static "tabularFunc.AlltabularFunc.exportAllTabularR15"(
    	String exportFileName	) {
    (new tabularFunc.AlltabularFunc()).exportAllTabularR15(
        	exportFileName)
}


def static "tabularFunc.AlltabularFunc.openTabularConfig"() {
    (new tabularFunc.AlltabularFunc()).openTabularConfig()
}


def static "tabularFunc.AlltabularFunc.previewTabularEnable"() {
    (new tabularFunc.AlltabularFunc()).previewTabularEnable()
}


def static "tabularFunc.AlltabularFunc.previewTabularDisable"() {
    (new tabularFunc.AlltabularFunc()).previewTabularDisable()
}


def static "tabularFunc.AlltabularFunc.previewStatus"(
    	String preview	) {
    (new tabularFunc.AlltabularFunc()).previewStatus(
        	preview)
}


def static "tabularFunc.AlltabularFunc.imageTabularEnable"(
    	String ImageTabularEnable	) {
    (new tabularFunc.AlltabularFunc()).imageTabularEnable(
        	ImageTabularEnable)
}


def static "tabularFunc.AlltabularFunc.imageTabularDisable"() {
    (new tabularFunc.AlltabularFunc()).imageTabularDisable()
}


def static "tabularFunc.AlltabularFunc.imageTStatus"(
    	String imgInTbl	) {
    (new tabularFunc.AlltabularFunc()).imageTStatus(
        	imgInTbl)
}


def static "tabularFunc.AlltabularFunc.rowSubTotal15"(
    	String rFieldnm	
     , 	String rowSubTotal	
     , 	String vSep	) {
    (new tabularFunc.AlltabularFunc()).rowSubTotal15(
        	rFieldnm
         , 	rowSubTotal
         , 	vSep)
}


def static "tabularFunc.AlltabularFunc.itemcountEnable"() {
    (new tabularFunc.AlltabularFunc()).itemcountEnable()
}


def static "tabularFunc.AlltabularFunc.itemcountDisable"() {
    (new tabularFunc.AlltabularFunc()).itemcountDisable()
}


def static "tabularFunc.AlltabularFunc.itemCountStatus"(
    	String itemCount	) {
    (new tabularFunc.AlltabularFunc()).itemCountStatus(
        	itemCount)
}


def static "tabularFunc.AlltabularFunc.setTableName"(
    	String tableName	) {
    (new tabularFunc.AlltabularFunc()).setTableName(
        	tableName)
}


def static "tabularFunc.AlltabularFunc.chkAttributesT"(
    	String attrNames	
     , 	String nSep	
     , 	String to	) {
    (new tabularFunc.AlltabularFunc()).chkAttributesT(
        	attrNames
         , 	nSep
         , 	to)
}


def static "tabularFunc.AlltabularFunc.chkMeasuresT"(
    	String msrNames	
     , 	String nSep	
     , 	String to	) {
    (new tabularFunc.AlltabularFunc()).chkMeasuresT(
        	msrNames
         , 	nSep
         , 	to)
}


def static "tabularFunc.AlltabularFunc.rowFieldsDD"(
    	String rowFields	
     , 	String nSep	
     , 	String to	) {
    (new tabularFunc.AlltabularFunc()).rowFieldsDD(
        	rowFields
         , 	nSep
         , 	to)
}


def static "tabularFunc.AlltabularFunc.colFieldsDD"(
    	String colFields	
     , 	String nSep	
     , 	String to	) {
    (new tabularFunc.AlltabularFunc()).colFieldsDD(
        	colFields
         , 	nSep
         , 	to)
}


def static "tabularFunc.AlltabularFunc.dataFieldsDD"(
    	String dataFields	
     , 	String nSep	
     , 	String to	) {
    (new tabularFunc.AlltabularFunc()).dataFieldsDD(
        	dataFields
         , 	nSep
         , 	to)
}


def static "tabularFunc.AlltabularFunc.setAggrForMsr"(
    	String msrNameT	
     , 	String aggrType	
     , 	String nSep	) {
    (new tabularFunc.AlltabularFunc()).setAggrForMsr(
        	msrNameT
         , 	aggrType
         , 	nSep)
}


def static "tabularFunc.AlltabularFunc.TabularApply"() {
    (new tabularFunc.AlltabularFunc()).TabularApply()
}


def static "tabularFunc.AlltabularFunc.downloadExportFile"(
    	String exportFileName	) {
    (new tabularFunc.AlltabularFunc()).downloadExportFile(
        	exportFileName)
}


def static "tabularFunc.AlltabularFunc.compareTabular"(
    	String exportFileName	
     , 	String expectedPath	
     , 	String actualPath	) {
    (new tabularFunc.AlltabularFunc()).compareTabular(
        	exportFileName
         , 	expectedPath
         , 	actualPath)
}


def static "tabularFunc.AlltabularFunc.configTabular"(
    	String rowFields	
     , 	String colFields	
     , 	String dataFields	
     , 	String nSep	
     , 	String vSep	
     , 	String to	
     , 	String msrNameT	
     , 	String aggrType	
     , 	String rowSubTotal	
     , 	String rFieldnm	
     , 	String cFieldnm	
     , 	String preview	
     , 	String ImageTabularEnable	
     , 	String colSubTotal	
     , 	String grandTotal	
     , 	String itemCount	
     , 	String tableName	) {
    (new tabularFunc.AlltabularFunc()).configTabular(
        	rowFields
         , 	colFields
         , 	dataFields
         , 	nSep
         , 	vSep
         , 	to
         , 	msrNameT
         , 	aggrType
         , 	rowSubTotal
         , 	rFieldnm
         , 	cFieldnm
         , 	preview
         , 	ImageTabularEnable
         , 	colSubTotal
         , 	grandTotal
         , 	itemCount
         , 	tableName)
}


def static "tabularFunc.AlltabularFunc.configTabularR15"(
    	String rowFields	
     , 	String colFields	
     , 	String dataFields	
     , 	String nSep	
     , 	String vSep	
     , 	String to	
     , 	String msrNameT	
     , 	String aggrType	
     , 	String rowSubTotal	
     , 	String rFieldnm	
     , 	String colSubTotal	
     , 	String cFieldnm	
     , 	String preview	
     , 	String ImageTabularEnable	
     , 	String itemCount	
     , 	String tableName	) {
    (new tabularFunc.AlltabularFunc()).configTabularR15(
        	rowFields
         , 	colFields
         , 	dataFields
         , 	nSep
         , 	vSep
         , 	to
         , 	msrNameT
         , 	aggrType
         , 	rowSubTotal
         , 	rFieldnm
         , 	colSubTotal
         , 	cFieldnm
         , 	preview
         , 	ImageTabularEnable
         , 	itemCount
         , 	tableName)
}


def static "tabularFunc.AlltabularFunc.copyPivotTbl"(
    	String copyPivot	) {
    (new tabularFunc.AlltabularFunc()).copyPivotTbl(
        	copyPivot)
}


def static "tabularFunc.AlltabularFunc.resetAllTbls"(
    	String removeAlltbls	) {
    (new tabularFunc.AlltabularFunc()).resetAllTbls(
        	removeAlltbls)
}


def static "tabularFunc.AlltabularFunc.duplicatePivot"(
    	String duplicateTbl	) {
    (new tabularFunc.AlltabularFunc()).duplicatePivot(
        	duplicateTbl)
}


def static "tabularFunc.AlltabularFunc.newTabular"(
    	String newTbl	) {
    (new tabularFunc.AlltabularFunc()).newTabular(
        	newTbl)
}


def static "tabularFunc.AlltabularFunc.tblclickAttrVals"(
    	String tattrNames	
     , 	String tvals	
     , 	String vSep	) {
    (new tabularFunc.AlltabularFunc()).tblclickAttrVals(
        	tattrNames
         , 	tvals
         , 	vSep)
}


def static "tabularFunc.AlltabularFunc.clickAttrValSearchInput"() {
    (new tabularFunc.AlltabularFunc()).clickAttrValSearchInput()
}


def static "tabularFunc.AlltabularFunc.tblselAttrNdVals"(
    	String tattrNames	
     , 	String tattrVals	
     , 	String nSep	
     , 	String vSep	) {
    (new tabularFunc.AlltabularFunc()).tblselAttrNdVals(
        	tattrNames
         , 	tattrVals
         , 	nSep
         , 	vSep)
}


def static "tabularFunc.AlltabularFunc.resetAttrOrMsr"(
    	String resetAttrOrMsrnm	
     , 	String nSep	) {
    (new tabularFunc.AlltabularFunc()).resetAttrOrMsr(
        	resetAttrOrMsrnm
         , 	nSep)
}


def static "tabularFunc.AlltabularFunc.tdoSort"(
    	String tsortAttrName	
     , 	String tattrStatus	
     , 	String nSep	
     , 	String vSep	) {
    (new tabularFunc.AlltabularFunc()).tdoSort(
        	tsortAttrName
         , 	tattrStatus
         , 	nSep
         , 	vSep)
}


def static "tabularFunc.AlltabularFunc.tdoSortR15"(
    	String tsortAttrName	
     , 	String tattrStatus	
     , 	String nSep	
     , 	String vSep	) {
    (new tabularFunc.AlltabularFunc()).tdoSortR15(
        	tsortAttrName
         , 	tattrStatus
         , 	nSep
         , 	vSep)
}


def static "tabularFunc.AlltabularFunc.tmDoSort"(
    	String tsortAttrName	
     , 	String tattrStatus	
     , 	String vSep	) {
    (new tabularFunc.AlltabularFunc()).tmDoSort(
        	tsortAttrName
         , 	tattrStatus
         , 	vSep)
}


def static "tabularFunc.AlltabularFunc.tmDoSort15"(
    	String tsortAttrName	
     , 	String tattrStatus	
     , 	String vSep	) {
    (new tabularFunc.AlltabularFunc()).tmDoSort15(
        	tsortAttrName
         , 	tattrStatus
         , 	vSep)
}


def static "tabularFunc.AlltabularFunc.trowdoSort"(
    	String tsortRAttrName	
     , 	String tattrRStatus	
     , 	String nSep	
     , 	String vSep	) {
    (new tabularFunc.AlltabularFunc()).trowdoSort(
        	tsortRAttrName
         , 	tattrRStatus
         , 	nSep
         , 	vSep)
}


def static "tabularFunc.AlltabularFunc.trowdoSortR15"(
    	String tsortRAttrName	
     , 	String tattrRStatus	
     , 	String nSep	
     , 	String vSep	) {
    (new tabularFunc.AlltabularFunc()).trowdoSortR15(
        	tsortRAttrName
         , 	tattrRStatus
         , 	nSep
         , 	vSep)
}


def static "tabularFunc.AlltabularFunc.tmrowDoSort"(
    	String tsortRAttrName	
     , 	String tattrRStatus	
     , 	String vSep	) {
    (new tabularFunc.AlltabularFunc()).tmrowDoSort(
        	tsortRAttrName
         , 	tattrRStatus
         , 	vSep)
}


def static "tabularFunc.AlltabularFunc.tmrowDoSortR15"(
    	String tsortRAttrName	
     , 	String tattrRStatus	
     , 	String vSep	) {
    (new tabularFunc.AlltabularFunc()).tmrowDoSortR15(
        	tsortRAttrName
         , 	tattrRStatus
         , 	vSep)
}


def static "tabularFunc.AlltabularFunc.tblFilters"(
    	String tattrNames	
     , 	String tattrVals	
     , 	String nSep	
     , 	String vSep	) {
    (new tabularFunc.AlltabularFunc()).tblFilters(
        	tattrNames
         , 	tattrVals
         , 	nSep
         , 	vSep)
}


def static "com.test.demo.DashboardCustomFunctions.NavMySelection"() {
    (new com.test.demo.DashboardCustomFunctions()).NavMySelection()
}


def static "layoutFunc.AlllayoutFunc.loadTemplate"(
    	String tempName	) {
    (new layoutFunc.AlllayoutFunc()).loadTemplate(
        	tempName)
}


def static "layoutFunc.AlllayoutFunc.currentTemplate"() {
    (new layoutFunc.AlllayoutFunc()).currentTemplate()
}


def static "layoutFunc.AlllayoutFunc.clickOnExportBtnL"() {
    (new layoutFunc.AlllayoutFunc()).clickOnExportBtnL()
}


def static "layoutFunc.AlllayoutFunc.exportTemplateL"(
    	String tplExportFnm	
     , 	String tplExportFormat	) {
    (new layoutFunc.AlllayoutFunc()).exportTemplateL(
        	tplExportFnm
         , 	tplExportFormat)
}


def static "layoutFunc.AlllayoutFunc.switchToScheduleL"() {
    (new layoutFunc.AlllayoutFunc()).switchToScheduleL()
}


def static "layoutFunc.AlllayoutFunc.selectExportMode"() {
    (new layoutFunc.AlllayoutFunc()).selectExportMode()
}


def static "layoutFunc.AlllayoutFunc.exportFormat"(
    	String formatType	) {
    (new layoutFunc.AlllayoutFunc()).exportFormat(
        	formatType)
}


def static "com.test.demo.KanvasLoginCustomFunctions.CID3User43"(
    	String URL	
     , 	String userName	
     , 	String pwd	) {
    (new com.test.demo.KanvasLoginCustomFunctions()).CID3User43(
        	URL
         , 	userName
         , 	pwd)
}


def static "com.test.demo.KanvasLoginCustomFunctions.KLogin"() {
    (new com.test.demo.KanvasLoginCustomFunctions()).KLogin()
}


def static "com.test.demo.KanvasLoginCustomFunctions.KLoginSYSTST"() {
    (new com.test.demo.KanvasLoginCustomFunctions()).KLoginSYSTST()
}


def static "com.test.demo.KanvasLoginCustomFunctions.KLoginUser65"() {
    (new com.test.demo.KanvasLoginCustomFunctions()).KLoginUser65()
}


def static "com.test.demo.KanvasLoginCustomFunctions.CID001Login"() {
    (new com.test.demo.KanvasLoginCustomFunctions()).CID001Login()
}


def static "com.test.demo.KanvasLoginCustomFunctions.KLoginBenjaminuser43"() {
    (new com.test.demo.KanvasLoginCustomFunctions()).KLoginBenjaminuser43()
}

/***********My Selection Main Functions**************************/
def static "com.BB.genralFunctions.warningForHigherCols"() {
    (new com.BB.genralFunctions()).warningForHigherCols()
}


def static "com.BB.genralFunctions.loadTemplate"(
    	String tempName	) {
    (new com.BB.genralFunctions()).loadTemplate(
        	tempName)
}


def static "com.BB.genralFunctions.currentTemplate"() {
    (new com.BB.genralFunctions()).currentTemplate()
}


def static "com.BB.genralFunctions.exportTemplateL"(
    	String tplExportFnm	
     , 	String tplExportFormat	) {
    (new com.BB.genralFunctions()).exportTemplateL(
        	tplExportFnm
         , 	tplExportFormat)
}


def static "com.BB.genralFunctions.ResetAllFlts"() {
    (new com.BB.genralFunctions()).ResetAllFlts()
}


def static "com.BB.genralFunctions.shortDelay"() {
    (new com.BB.genralFunctions()).shortDelay()
}


def static "com.BB.genralFunctions.waitTill"(
    	Object waiT	) {
    (new com.BB.genralFunctions()).waitTill(
        	waiT)
}


def static "com.BB.genralFunctions.longDelay"() {
    (new com.BB.genralFunctions()).longDelay()
}


def static "com.BB.genralFunctions.longestDelay"() {
    (new com.BB.genralFunctions()).longestDelay()
}


def static "com.BB.genralFunctions.startFresh"(
    	String startFresh	) {
    (new com.BB.genralFunctions()).startFresh(
        	startFresh)
}


def static "com.BB.genralFunctions.fullScrn"() {
    (new com.BB.genralFunctions()).fullScrn()
}


def static "com.BB.genralFunctions.FilterApplyBtn"() {
    (new com.BB.genralFunctions()).FilterApplyBtn()
}


def static "com.BB.genralFunctions.sideMenuBar"() {
    (new com.BB.genralFunctions()).sideMenuBar()
}


def static "com.BB.genralFunctions.clickAttrVals"(
    	String vals	
     , 	String vSep	) {
    (new com.BB.genralFunctions()).clickAttrVals(
        	vals
         , 	vSep)
}


def static "com.BB.genralFunctions.selAttrNdVals"(
    	String attrNames	
     , 	String attrVals	
     , 	String nSep	
     , 	String vSep	) {
    (new com.BB.genralFunctions()).selAttrNdVals(
        	attrNames
         , 	attrVals
         , 	nSep
         , 	vSep)
}


def static "com.BB.genralFunctions.selHAttrNdVals"(
    	String hAttrNames	
     , 	String hAttrVals	
     , 	String nSep	
     , 	String vSep	) {
    (new com.BB.genralFunctions()).selHAttrNdVals(
        	hAttrNames
         , 	hAttrVals
         , 	nSep
         , 	vSep)
}


def static "com.BB.genralFunctions.SetMsrValbyFunc"(
    	String msrNames	
     , 	String minVal	
     , 	String maxVal	
     , 	String nSep	) {
    (new com.BB.genralFunctions()).SetMsrValbyFunc(
        	msrNames
         , 	minVal
         , 	maxVal
         , 	nSep)
}


def static "com.BB.genralFunctions.setMsrMinVal"(
    	String minVal	
     , 	String vSep	) {
    (new com.BB.genralFunctions()).setMsrMinVal(
        	minVal
         , 	vSep)
}


def static "com.BB.genralFunctions.setMsrMaxVal"(
    	String maxVal	
     , 	String vSep	) {
    (new com.BB.genralFunctions()).setMsrMaxVal(
        	maxVal
         , 	vSep)
}


def static "com.BB.genralFunctions.setTextTag"(
    	String TextTag	
     , 	String nSep	) {
    (new com.BB.genralFunctions()).setTextTag(
        	TextTag
         , 	nSep)
}

/**   *****************Group By attributes and Tags ***************        **/
def static "com.BB.genralFunctions.clickGrpAttrs"(
    	String groupByAttrName	
     , 	String nSep	) {
    (new com.BB.genralFunctions()).clickGrpAttrs(
        	groupByAttrName
         , 	nSep)
}


def static "com.BB.genralFunctions.clickGrpTags"(
    	String TextTag	) {
    (new com.BB.genralFunctions()).clickGrpTags(
        	TextTag)
}


def static "com.BB.genralFunctions.sortDone"(
    	String sortAttrName	
     , 	String statsAttrName	) {
    (new com.BB.genralFunctions()).sortDone(
        	sortAttrName
         , 	statsAttrName)
}


def static "com.BB.genralFunctions.doneSortBtn"() {
    (new com.BB.genralFunctions()).doneSortBtn()
}


def static "com.BB.genralFunctions.doSort"(
    	String sortAttrName	
     , 	String attrStatus	
     , 	String nSep	
     , 	String vSep	) {
    (new com.BB.genralFunctions()).doSort(
        	sortAttrName
         , 	attrStatus
         , 	nSep
         , 	vSep)
}


def static "com.BB.genralFunctions.doStats"(
    	String statsAttrName	
     , 	String nSep	) {
    (new com.BB.genralFunctions()).doStats(
        	statsAttrName
         , 	nSep)
}


def static "com.BB.genralFunctions.mDoSort"(
    	String sortAttrName	
     , 	String attrStatus	
     , 	String vSep	) {
    (new com.BB.genralFunctions()).mDoSort(
        	sortAttrName
         , 	attrStatus
         , 	vSep)
}


def static "com.BB.genralFunctions.groupSortTab"(
    	String grpsortAttrName	
     , 	String grpattrStatus	
     , 	String aggrVal	
     , 	String vSep	
     , 	String nSep	) {
    (new com.BB.genralFunctions()).groupSortTab(
        	grpsortAttrName
         , 	grpattrStatus
         , 	aggrVal
         , 	vSep
         , 	nSep)
}


def static "com.BB.genralFunctions.groupmDoSort"(
    	String grpsortAttrName	
     , 	String grpattrStatus	
     , 	String vSep	) {
    (new com.BB.genralFunctions()).groupmDoSort(
        	grpsortAttrName
         , 	grpattrStatus
         , 	vSep)
}


def static "com.BB.genralFunctions.grpSortAggr"(
    	String grpsortAttrName	
     , 	String aggrVal	) {
    (new com.BB.genralFunctions()).grpSortAggr(
        	grpsortAttrName
         , 	aggrVal)
}


def static "com.BB.genralFunctions.setItemLimit"(
    	Object limit	) {
    (new com.BB.genralFunctions()).setItemLimit(
        	limit)
}


def static "com.BB.genralFunctions.enableShowData"() {
    (new com.BB.genralFunctions()).enableShowData()
}


def static "com.BB.genralFunctions.enableHideData"() {
    (new com.BB.genralFunctions()).enableHideData()
}


def static "com.BB.genralFunctions.doShowData"(
    	String showDataAttrName	
     , 	String nSep	) {
    (new com.BB.genralFunctions()).doShowData(
        	showDataAttrName
         , 	nSep)
}


def static "com.BB.genralFunctions.saveShowData"() {
    (new com.BB.genralFunctions()).saveShowData()
}


def static "com.BB.genralFunctions.HierarchyBtn"() {
    (new com.BB.genralFunctions()).HierarchyBtn()
}


def static "com.BB.genralFunctions.HierarchySave"() {
    (new com.BB.genralFunctions()).HierarchySave()
}


def static "com.BB.genralFunctions.ScrollTo"(
    	Object obj	
     , 	Object timeout	) {
    (new com.BB.genralFunctions()).ScrollTo(
        	obj
         , 	timeout)
}


def static "com.BB.genralFunctions.clickUsingJS"(
    	TestObject to	
     , 	int timeout	) {
    (new com.BB.genralFunctions()).clickUsingJS(
        	to
         , 	timeout)
}


def static "com.BB.genralFunctions.clickUserLoginDropDown"() {
    (new com.BB.genralFunctions()).clickUserLoginDropDown()
}


def static "com.BB.genralFunctions.alertHandling"() {
    (new com.BB.genralFunctions()).alertHandling()
}


def static "com.BB.genralFunctions.CompareItemCnt"(
    	String expected	) {
    (new com.BB.genralFunctions()).CompareItemCnt(
        	expected)
}


def static "com.BB.genralFunctions.actualItemCntFlt"(
    	String expected	) {
    (new com.BB.genralFunctions()).actualItemCntFlt(
        	expected)
}


def static "com.BB.genralFunctions.actualItemCntGrp"(
    	String expected	) {
    (new com.BB.genralFunctions()).actualItemCntGrp(
        	expected)
}


def static "com.BB.genralFunctions.CompareTooltipInfo"(
    	Object tiexpected	
     , 	Object tiactual	) {
    (new com.BB.genralFunctions()).CompareTooltipInfo(
        	tiexpected
         , 	tiactual)
}


def static "com.BB.genralFunctions.CompareStatsSummary"(
    	Object tiexpected	
     , 	Object tiactual	) {
    (new com.BB.genralFunctions()).CompareStatsSummary(
        	tiexpected
         , 	tiactual)
}


def static "com.BB.genralFunctions.ClickInfoBtn"() {
    (new com.BB.genralFunctions()).ClickInfoBtn()
}


def static "com.BB.genralFunctions.TabularItemCount"() {
    (new com.BB.genralFunctions()).TabularItemCount()
}


def static "com.BB.genralFunctions.Stndardcnt"() {
    (new com.BB.genralFunctions()).Stndardcnt()
}


def static "com.BB.genralFunctions.tabVsStdcnt"() {
    (new com.BB.genralFunctions()).tabVsStdcnt()
}


def static "com.BB.genralFunctions.getActualItemCntG"() {
    (new com.BB.genralFunctions()).getActualItemCntG()
}


def static "com.BB.genralFunctions.saveWS"(
    	Object workspaceNameS	) {
    (new com.BB.genralFunctions()).saveWS(
        	workspaceNameS)
}


def static "com.BB.genralFunctions.SaveWorkspace"(
    	Object wsName	) {
    (new com.BB.genralFunctions()).SaveWorkspace(
        	wsName)
}


def static "com.BB.genralFunctions.loadWorkspace"(
    	String workspaceName	
     , 	String nSep	) {
    (new com.BB.genralFunctions()).loadWorkspace(
        	workspaceName
         , 	nSep)
}


def static "com.BB.genralFunctions.warningMsgChk"() {
    (new com.BB.genralFunctions()).warningMsgChk()
}


def static "com.BB.genralFunctions.switchToTabular"() {
    (new com.BB.genralFunctions()).switchToTabular()
}


def static "com.BB.genralFunctions.switchToLayoutFromTabular"() {
    (new com.BB.genralFunctions()).switchToLayoutFromTabular()
}


def static "com.BB.genralFunctions.downloadExportFileTR15"(
    	String exportFileName	) {
    (new com.BB.genralFunctions()).downloadExportFileTR15(
        	exportFileName)
}


def static "com.BB.genralFunctions.exportTabularFromDashboard"(
    	String exportFileName	) {
    (new com.BB.genralFunctions()).exportTabularFromDashboard(
        	exportFileName)
}


def static "com.BB.genralFunctions.compareTabularR15"(
    	String exportFileName	
     , 	String expectedPath	
     , 	String actualPath	) {
    (new com.BB.genralFunctions()).compareTabularR15(
        	exportFileName
         , 	expectedPath
         , 	actualPath)
}


def static "com.BB.genralFunctions.compareTabularR14"(
    	String expectedPath	
     , 	String actualPath	) {
    (new com.BB.genralFunctions()).compareTabularR14(
        	expectedPath
         , 	actualPath)
}


def static "com.BB.genralFunctions.exportAllTabularR14"(
    	String exportFileName	) {
    (new com.BB.genralFunctions()).exportAllTabularR14(
        	exportFileName)
}


def static "com.BB.genralFunctions.exportAllTabularR15"(
    	String exportFileName	) {
    (new com.BB.genralFunctions()).exportAllTabularR15(
        	exportFileName)
}


def static "com.BB.genralFunctions.switchToStandard"() {
    (new com.BB.genralFunctions()).switchToStandard()
}


def static "com.BB.genralFunctions.switchToLayoutFromStd"() {
    (new com.BB.genralFunctions()).switchToLayoutFromStd()
}


def static "com.BB.genralFunctions.openTabularConfig"() {
    (new com.BB.genralFunctions()).openTabularConfig()
}


def static "com.BB.genralFunctions.rowSubTotalEnable"(
    	String rowSubTotal	
     , 	String rFieldnm	) {
    (new com.BB.genralFunctions()).rowSubTotalEnable(
        	rowSubTotal
         , 	rFieldnm)
}


def static "com.BB.genralFunctions.rowSubTotalDisable"(
    	String rowSubTotal	
     , 	String rFieldnm	) {
    (new com.BB.genralFunctions()).rowSubTotalDisable(
        	rowSubTotal
         , 	rFieldnm)
}


def static "com.BB.genralFunctions.rowSubTotalStatus15"(
    	String rowSubTotal	
     , 	String rFieldnm	) {
    (new com.BB.genralFunctions()).rowSubTotalStatus15(
        	rowSubTotal
         , 	rFieldnm)
}


def static "com.BB.genralFunctions.rowSubTotalStatus"(
    	String rowSubTotal	) {
    (new com.BB.genralFunctions()).rowSubTotalStatus(
        	rowSubTotal)
}


def static "com.BB.genralFunctions.previewTabularEnable"() {
    (new com.BB.genralFunctions()).previewTabularEnable()
}


def static "com.BB.genralFunctions.previewTabularDisable"() {
    (new com.BB.genralFunctions()).previewTabularDisable()
}


def static "com.BB.genralFunctions.previewStatus"(
    	String preview	) {
    (new com.BB.genralFunctions()).previewStatus(
        	preview)
}


def static "com.BB.genralFunctions.imageTabularEnable"(
    	String ImageTabularEnable	) {
    (new com.BB.genralFunctions()).imageTabularEnable(
        	ImageTabularEnable)
}


def static "com.BB.genralFunctions.imageTabularDisable"() {
    (new com.BB.genralFunctions()).imageTabularDisable()
}


def static "com.BB.genralFunctions.imageTStatus"(
    	String imgInTbl	) {
    (new com.BB.genralFunctions()).imageTStatus(
        	imgInTbl)
}


def static "com.BB.genralFunctions.colSubTotalEnable"() {
    (new com.BB.genralFunctions()).colSubTotalEnable()
}


def static "com.BB.genralFunctions.colSubTotalDisable"() {
    (new com.BB.genralFunctions()).colSubTotalDisable()
}


def static "com.BB.genralFunctions.colSubTotalStatus"(
    	String colSubTotal	) {
    (new com.BB.genralFunctions()).colSubTotalStatus(
        	colSubTotal)
}


def static "com.BB.genralFunctions.colSubTotal15"(
    	String cFieldnm	
     , 	String colSubTotal	
     , 	String vSep	) {
    (new com.BB.genralFunctions()).colSubTotal15(
        	cFieldnm
         , 	colSubTotal
         , 	vSep)
}


def static "com.BB.genralFunctions.rowSubTotal15"(
    	String rFieldnm	
     , 	String rowSubTotal	
     , 	String vSep	) {
    (new com.BB.genralFunctions()).rowSubTotal15(
        	rFieldnm
         , 	rowSubTotal
         , 	vSep)
}


def static "com.BB.genralFunctions.colSubTotalDisable15"(
    	String colSubTotal	
     , 	String cFieldnm	) {
    (new com.BB.genralFunctions()).colSubTotalDisable15(
        	colSubTotal
         , 	cFieldnm)
}


def static "com.BB.genralFunctions.colSubTotalStatus15"(
    	String colSubTotal	
     , 	String cFieldnm	) {
    (new com.BB.genralFunctions()).colSubTotalStatus15(
        	colSubTotal
         , 	cFieldnm)
}


def static "com.BB.genralFunctions.grandTotalEnable"() {
    (new com.BB.genralFunctions()).grandTotalEnable()
}


def static "com.BB.genralFunctions.grandTotalDisable"() {
    (new com.BB.genralFunctions()).grandTotalDisable()
}


def static "com.BB.genralFunctions.grandTotalStatus"(
    	String grandTotal	) {
    (new com.BB.genralFunctions()).grandTotalStatus(
        	grandTotal)
}


def static "com.BB.genralFunctions.itemcountEnable"() {
    (new com.BB.genralFunctions()).itemcountEnable()
}


def static "com.BB.genralFunctions.itemcountDisable"() {
    (new com.BB.genralFunctions()).itemcountDisable()
}


def static "com.BB.genralFunctions.itemCountStatus"(
    	String itemCount	) {
    (new com.BB.genralFunctions()).itemCountStatus(
        	itemCount)
}


def static "com.BB.genralFunctions.setTableName"(
    	String tableName	) {
    (new com.BB.genralFunctions()).setTableName(
        	tableName)
}


def static "com.BB.genralFunctions.chkAttributesT"(
    	String attrNames	
     , 	String nSep	
     , 	String to	) {
    (new com.BB.genralFunctions()).chkAttributesT(
        	attrNames
         , 	nSep
         , 	to)
}


def static "com.BB.genralFunctions.chkMeasuresT"(
    	String msrNames	
     , 	String nSep	
     , 	String to	) {
    (new com.BB.genralFunctions()).chkMeasuresT(
        	msrNames
         , 	nSep
         , 	to)
}


def static "com.BB.genralFunctions.rowFieldsDD"(
    	String rowFields	
     , 	String nSep	
     , 	String to	) {
    (new com.BB.genralFunctions()).rowFieldsDD(
        	rowFields
         , 	nSep
         , 	to)
}


def static "com.BB.genralFunctions.colFieldsDD"(
    	String colFields	
     , 	String nSep	
     , 	String to	) {
    (new com.BB.genralFunctions()).colFieldsDD(
        	colFields
         , 	nSep
         , 	to)
}


def static "com.BB.genralFunctions.dataFieldsDD"(
    	String dataFields	
     , 	String nSep	
     , 	String to	) {
    (new com.BB.genralFunctions()).dataFieldsDD(
        	dataFields
         , 	nSep
         , 	to)
}


def static "com.BB.genralFunctions.setAggrForMsr"(
    	String msrNameT	
     , 	String aggrType	
     , 	String nSep	) {
    (new com.BB.genralFunctions()).setAggrForMsr(
        	msrNameT
         , 	aggrType
         , 	nSep)
}


def static "com.BB.genralFunctions.TabularApply"() {
    (new com.BB.genralFunctions()).TabularApply()
}


def static "com.BB.genralFunctions.downloadExportFile"(
    	String exportFileName	) {
    (new com.BB.genralFunctions()).downloadExportFile(
        	exportFileName)
}


def static "com.BB.genralFunctions.compareTabular"(
    	String exportFileName	
     , 	String expectedPath	
     , 	String actualPath	) {
    (new com.BB.genralFunctions()).compareTabular(
        	exportFileName
         , 	expectedPath
         , 	actualPath)
}


def static "com.BB.genralFunctions.configTabular"(
    	String rowFields	
     , 	String colFields	
     , 	String dataFields	
     , 	String nSep	
     , 	String to	
     , 	String msrNameT	
     , 	String aggrType	
     , 	String rowSubTotal	
     , 	String rFieldnm	
     , 	String cFieldnm	
     , 	String preview	
     , 	String ImageTabularEnable	
     , 	String colSubTotal	
     , 	String grandTotal	
     , 	String itemCount	
     , 	String tableName	) {
    (new com.BB.genralFunctions()).configTabular(
        	rowFields
         , 	colFields
         , 	dataFields
         , 	nSep
         , 	to
         , 	msrNameT
         , 	aggrType
         , 	rowSubTotal
         , 	rFieldnm
         , 	cFieldnm
         , 	preview
         , 	ImageTabularEnable
         , 	colSubTotal
         , 	grandTotal
         , 	itemCount
         , 	tableName)
}


def static "com.BB.genralFunctions.copyPivotTbl"(
    	String copyPivot	) {
    (new com.BB.genralFunctions()).copyPivotTbl(
        	copyPivot)
}


def static "com.BB.genralFunctions.resetAllTbls"(
    	String removeAlltbls	) {
    (new com.BB.genralFunctions()).resetAllTbls(
        	removeAlltbls)
}


def static "com.BB.genralFunctions.duplicatePivot"(
    	String duplicateTbl	) {
    (new com.BB.genralFunctions()).duplicatePivot(
        	duplicateTbl)
}


def static "com.BB.genralFunctions.newTabular"(
    	String newTbl	) {
    (new com.BB.genralFunctions()).newTabular(
        	newTbl)
}


def static "com.BB.genralFunctions.tblclickAttrVals"(
    	String tattrNames	
     , 	String tvals	
     , 	String vSep	) {
    (new com.BB.genralFunctions()).tblclickAttrVals(
        	tattrNames
         , 	tvals
         , 	vSep)
}


def static "com.BB.genralFunctions.clickAttrValSearchInput"() {
    (new com.BB.genralFunctions()).clickAttrValSearchInput()
}


def static "com.BB.genralFunctions.tblselAttrNdVals"(
    	String tattrNames	
     , 	String tattrVals	
     , 	String nSep	
     , 	String vSep	) {
    (new com.BB.genralFunctions()).tblselAttrNdVals(
        	tattrNames
         , 	tattrVals
         , 	nSep
         , 	vSep)
}


def static "com.BB.genralFunctions.resetAttrOrMsr"(
    	String resetAttrOrMsrnm	
     , 	String nSep	) {
    (new com.BB.genralFunctions()).resetAttrOrMsr(
        	resetAttrOrMsrnm
         , 	nSep)
}


def static "com.BB.genralFunctions.tdoSort"(
    	String tsortAttrName	
     , 	String tattrStatus	
     , 	String nSep	
     , 	String vSep	) {
    (new com.BB.genralFunctions()).tdoSort(
        	tsortAttrName
         , 	tattrStatus
         , 	nSep
         , 	vSep)
}


def static "com.BB.genralFunctions.tdoSortR15"(
    	String tsortAttrName	
     , 	String tattrStatus	
     , 	String nSep	
     , 	String vSep	) {
    (new com.BB.genralFunctions()).tdoSortR15(
        	tsortAttrName
         , 	tattrStatus
         , 	nSep
         , 	vSep)
}


def static "com.BB.genralFunctions.tmDoSort"(
    	String tsortAttrName	
     , 	String tattrStatus	
     , 	String vSep	) {
    (new com.BB.genralFunctions()).tmDoSort(
        	tsortAttrName
         , 	tattrStatus
         , 	vSep)
}


def static "com.BB.genralFunctions.tmDoSort15"(
    	String tsortAttrName	
     , 	String tattrStatus	
     , 	String vSep	) {
    (new com.BB.genralFunctions()).tmDoSort15(
        	tsortAttrName
         , 	tattrStatus
         , 	vSep)
}


def static "com.BB.genralFunctions.trowdoSort"(
    	String tsortRAttrName	
     , 	String tattrRStatus	
     , 	String nSep	
     , 	String vSep	) {
    (new com.BB.genralFunctions()).trowdoSort(
        	tsortRAttrName
         , 	tattrRStatus
         , 	nSep
         , 	vSep)
}


def static "com.BB.genralFunctions.trowdoSortR15"(
    	String tsortRAttrName	
     , 	String tattrRStatus	
     , 	String nSep	
     , 	String vSep	) {
    (new com.BB.genralFunctions()).trowdoSortR15(
        	tsortRAttrName
         , 	tattrRStatus
         , 	nSep
         , 	vSep)
}


def static "com.BB.genralFunctions.tmrowDoSort"(
    	String tsortRAttrName	
     , 	String tattrRStatus	
     , 	String vSep	) {
    (new com.BB.genralFunctions()).tmrowDoSort(
        	tsortRAttrName
         , 	tattrRStatus
         , 	vSep)
}


def static "com.BB.genralFunctions.tmrowDoSortR15"(
    	String tsortRAttrName	
     , 	String tattrRStatus	
     , 	String vSep	) {
    (new com.BB.genralFunctions()).tmrowDoSortR15(
        	tsortRAttrName
         , 	tattrRStatus
         , 	vSep)
}


def static "com.BB.genralFunctions.clickOnExportBtnL"() {
    (new com.BB.genralFunctions()).clickOnExportBtnL()
}


def static "com.BB.genralFunctions.switchToScheduleL"() {
    (new com.BB.genralFunctions()).switchToScheduleL()
}


def static "com.BB.genralFunctions.selectExportMode"() {
    (new com.BB.genralFunctions()).selectExportMode()
}


def static "com.BB.genralFunctions.exportFormat"(
    	String formatType	) {
    (new com.BB.genralFunctions()).exportFormat(
        	formatType)
}


def static "com.BB.genralFunctions.shareWS"(
    	String shareStatus	
     , 	String shareUser	
     , 	String vSep	) {
    (new com.BB.genralFunctions()).shareWS(
        	shareStatus
         , 	shareUser
         , 	vSep)
}


def static "com.BB.genralFunctions.clickOnShareIcon"(
    	String wsNameShare	
     , 	String nSep	) {
    (new com.BB.genralFunctions()).clickOnShareIcon(
        	wsNameShare
         , 	nSep)
}


def static "com.BB.genralFunctions.doShareWS"(
    	String wsNameShare	
     , 	String shareStatus	
     , 	String shareUser	
     , 	String vSep	
     , 	String nSep	) {
    (new com.BB.genralFunctions()).doShareWS(
        	wsNameShare
         , 	shareStatus
         , 	shareUser
         , 	vSep
         , 	nSep)
}


def static "com.BB.genralFunctions.myWSTab"() {
    (new com.BB.genralFunctions()).myWSTab()
}


def static "com.BB.genralFunctions.sharedWSTab"() {
    (new com.BB.genralFunctions()).sharedWSTab()
}


def static "com.BB.genralFunctions.SwitchtoWorkspace"() {
    (new com.BB.genralFunctions()).SwitchtoWorkspace()
}

/**
	 * @param tag (String) The tag element used to find the target element.
	 * @param to (TestObject) constructed TestObject
	 * @return (TestObject) The constructed TestObject.
	 */
def static "com.BB.genralFunctions.makeToTag"(
    	String tag	
     , 	TestObject to	) {
    (new com.BB.genralFunctions()).makeToTag(
        	tag
         , 	to)
}

/**
	 * @param text (String) The text used to find the target element.
	 * @param to (TestObject) constructed TestObject
	 * @return (TestObject) The constructed TestObject.
	 */
def static "com.BB.genralFunctions.makeToText"(
    	String text	
     , 	TestObject to	) {
    (new com.BB.genralFunctions()).makeToText(
        	text
         , 	to)
}

/**
	 * @param css (String) The class name used to find the target element.
	 * @param to (TestObject) constructed TestObject
	 * @return (TestObject) The constructed TestObject.
	 */
def static "com.BB.genralFunctions.makeToCssCls"(
    	String css	
     , 	TestObject to	) {
    (new com.BB.genralFunctions()).makeToCssCls(
        	css
         , 	to)
}

/**
	 * @param css (String) The id name used to find the target element.
	 * @param to (TestObject) constructed TestObject
	 * @return (TestObject) The constructed TestObject.
	 */
def static "com.BB.genralFunctions.makeToCssId"(
    	String css	
     , 	TestObject to	) {
    (new com.BB.genralFunctions()).makeToCssId(
        	css
         , 	to)
}

/**
	 * @param data (String) The data attribute used to find the target element.(ex: for,data-value,title)
	 * @param val (String) The value of data attribute used to find the target element.
	 * @param to (TestObject) constructed TestObject
	 * @return (TestObject) The constructed TestObject.
	 */
def static "com.BB.genralFunctions.makeToDataVal"(
    	String data	
     , 	String val	
     , 	TestObject to	) {
    (new com.BB.genralFunctions()).makeToDataVal(
        	data
         , 	val
         , 	to)
}


def static "com.BB.genralFunctions.makeToXpath"(
    	String xpath	
     , 	TestObject to	) {
    (new com.BB.genralFunctions()).makeToXpath(
        	xpath
         , 	to)
}


def static "com.BB.genralFunctions.makeToSDXpath"(
    	String SDxpath	
     , 	TestObject to	) {
    (new com.BB.genralFunctions()).makeToSDXpath(
        	SDxpath
         , 	to)
}


def static "com.BB.genralFunctions.makeToSDXpathI"(
    	String SDxpathI	
     , 	TestObject to	) {
    (new com.BB.genralFunctions()).makeToSDXpathI(
        	SDxpathI
         , 	to)
}


def static "com.BB.genralFunctions.makeToSTXpath"(
    	String STxpath	
     , 	TestObject to	) {
    (new com.BB.genralFunctions()).makeToSTXpath(
        	STxpath
         , 	to)
}


def static "com.BB.genralFunctions.makeToSTXpathI"(
    	String STxpathI	
     , 	TestObject to	) {
    (new com.BB.genralFunctions()).makeToSTXpathI(
        	STxpathI
         , 	to)
}

/**
	 * Wrapper function for Katalon-compatible Test Object construct functions
	 * @param tag (String) The tag element used to find the target element.
	 * @param text (String) The text used to find the target element.
	 * @param cls (String) The class name used to find the target element.
	 * @param id (String) The id name used to find the target element.
	 * @param data, val (String, String) The data attribute and it's value used to find the target element.
	 * @return (TestObject) The constructed TestObject.
	 */
def static "com.BB.genralFunctions.makeTestObject"(
    	String tag	
     , 	String text	
     , 	String cls	
     , 	String id	
     , 	String data	
     , 	String val	
     , 	String xpath	) {
    (new com.BB.genralFunctions()).makeTestObject(
        	tag
         , 	text
         , 	cls
         , 	id
         , 	data
         , 	val
         , 	xpath)
}
