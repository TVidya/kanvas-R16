package internal

import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.main.TestCaseMain


/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */
public class GlobalVariable {
     
    /**
     * <p>Profile default : default user credentials</p>
     */
    public static Object demo_usn
     
    /**
     * <p>Profile default : password</p>
     */
    public static Object demo_pwd
     
    /**
     * <p>Profile default : userid</p>
     */
    public static Object CID010_usn
     
    /**
     * <p>Profile default : pwd</p>
     */
    public static Object CID010_pwd
     
    /**
     * <p>Profile default : userid</p>
     */
    public static Object CID008_usn
     
    /**
     * <p>Profile default : pwd</p>
     */
    public static Object CID008_pwd
     
    /**
     * <p></p>
     */
    public static Object User64
     
    /**
     * <p></p>
     */
    public static Object User64PWD
     
    /**
     * <p></p>
     */
    public static Object User65
     
    /**
     * <p></p>
     */
    public static Object User65PWD
     
    /**
     * <p>Profile default : Benjimanparker</p>
     */
    public static Object BUser43
     
    /**
     * <p></p>
     */
    public static Object B43PWD
     
    /**
     * <p></p>
     */
    public static Object Path
     
    /**
     * <p></p>
     */
    public static Object Filename
     
    /**
     * <p></p>
     */
    public static Object SSpath
     
    /**
     * <p></p>
     */
    public static Object shortDelay
     
    /**
     * <p></p>
     */
    public static Object longDelay
     
    /**
     * <p></p>
     */
    public static Object longestDelay
     
    /**
     * <p></p>
     */
    public static Object pUser
     
    /**
     * <p></p>
     */
    public static Object pPWD
     
    /**
     * <p></p>
     */
    public static Object LocalU
     
    /**
     * <p></p>
     */
    public static Object Localpwd
     
    /**
     * <p></p>
     */
    public static Object cid1USER
     
    /**
     * <p></p>
     */
    public static Object cid1PWD
     
    /**
     * <p></p>
     */
    public static Object subject
     
    /**
     * <p></p>
     */
    public static Object CIDname
     
    /**
     * <p></p>
     */
    public static Object NFTC
     

    static {
        try {
            def selectedVariables = TestCaseMain.getGlobalVariables("default")
			selectedVariables += TestCaseMain.getGlobalVariables(RunConfiguration.getExecutionProfile())
            selectedVariables += RunConfiguration.getOverridingParameters()
    
            demo_usn = selectedVariables['demo_usn']
            demo_pwd = selectedVariables['demo_pwd']
            CID010_usn = selectedVariables['CID010_usn']
            CID010_pwd = selectedVariables['CID010_pwd']
            CID008_usn = selectedVariables['CID008_usn']
            CID008_pwd = selectedVariables['CID008_pwd']
            User64 = selectedVariables['User64']
            User64PWD = selectedVariables['User64PWD']
            User65 = selectedVariables['User65']
            User65PWD = selectedVariables['User65PWD']
            BUser43 = selectedVariables['BUser43']
            B43PWD = selectedVariables['B43PWD']
            Path = selectedVariables['Path']
            Filename = selectedVariables['Filename']
            SSpath = selectedVariables['SSpath']
            shortDelay = selectedVariables['shortDelay']
            longDelay = selectedVariables['longDelay']
            longestDelay = selectedVariables['longestDelay']
            pUser = selectedVariables['pUser']
            pPWD = selectedVariables['pPWD']
            LocalU = selectedVariables['LocalU']
            Localpwd = selectedVariables['Localpwd']
            cid1USER = selectedVariables['cid1USER']
            cid1PWD = selectedVariables['cid1PWD']
            subject = selectedVariables['subject']
            CIDname = selectedVariables['CIDname']
            NFTC = selectedVariables['NFTC']
            
        } catch (Exception e) {
            TestCaseMain.logGlobalVariableError(e)
        }
    }
}
