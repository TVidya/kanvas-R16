<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Runstill-selMonthYr</name>
   <tag></tag>
   <elementGuidId>91055628-7436-40f0-ba34-9e82dd304c40</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//th[(text() = 'October 2019' or . = 'October 2019')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>th</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>October 2019</value>
   </webElementProperties>
</WebElementEntity>
