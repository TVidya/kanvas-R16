<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>IncludeTextTag-ExportData</name>
   <tag></tag>
   <elementGuidId>239fae51-cd94-4b0a-b91f-e603cdacb1f4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='exportFormStl']/div[2]/div[2]/div[4]/div/label</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>id(&quot;exportFormStl&quot;)/div[@class=&quot;row dtmplate&quot;]/div[@class=&quot;col-md-6 col-lg-6&quot;]/div[@class=&quot;row alignRowiseTemp&quot;]/div[@class=&quot;chk-div col-md-4 lblDataExp1&quot;]/label[@class=&quot;lbl_cls chkTag_lbl&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>label</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;exportFormStl&quot;)/div[@class=&quot;row dtmplate&quot;]/div[@class=&quot;col-md-6 col-lg-6&quot;]/div[@class=&quot;row alignRowiseTemp&quot;]/div[@class=&quot;chk-div col-md-4 lblDataExp1&quot;]/label[@class=&quot;lbl_cls chkTag_lbl&quot;]</value>
   </webElementProperties>
</WebElementEntity>
