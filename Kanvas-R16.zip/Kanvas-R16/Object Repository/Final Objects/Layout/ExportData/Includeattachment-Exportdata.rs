<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Includeattachment-Exportdata</name>
   <tag></tag>
   <elementGuidId>1a676afd-9f81-4f4a-81ce-4a21232b2526</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>id(&quot;expAttachmentAcl&quot;)/div[@class=&quot;chk-div col-md-4 lblDataExp1&quot;]/label[@class=&quot;lbl_cls chkTag_lbl&quot;][count(. | //label[@for = 'expAttachment']) = count(//label[@for = 'expAttachment'])]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>label</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;expAttachmentAcl&quot;)/div[@class=&quot;chk-div col-md-4 lblDataExp1&quot;]/label[@class=&quot;lbl_cls chkTag_lbl&quot;]</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>for</name>
      <type>Main</type>
      <value>expAttachment</value>
   </webElementProperties>
</WebElementEntity>
