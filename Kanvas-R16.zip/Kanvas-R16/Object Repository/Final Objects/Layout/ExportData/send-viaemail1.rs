<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>send-viaemail1</name>
   <tag></tag>
   <elementGuidId>5b2e9694-1849-422d-9a63-aa0dec7ca98b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//label[(text() = 'Send via Email' or . = 'Send via Email')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>label</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Send via Email</value>
   </webElementProperties>
</WebElementEntity>
