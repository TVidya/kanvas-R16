<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_Licensed to CID 005</name>
   <tag></tag>
   <elementGuidId>35b10515-9110-4134-a162-7cd8f1cf099e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>id(&quot;bodyContent&quot;)/div[@class=&quot;row&quot;]/div[@class=&quot;about-content&quot;]/aside[@class=&quot;right-side&quot;]/section[@class=&quot;content&quot;]/center[1]/p[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Licensed to CID 005</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;bodyContent&quot;)/div[@class=&quot;row&quot;]/div[@class=&quot;about-content&quot;]/aside[@class=&quot;right-side&quot;]/section[@class=&quot;content&quot;]/center[1]/p[2]</value>
   </webElementProperties>
</WebElementEntity>
