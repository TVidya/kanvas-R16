<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>annu-edit</name>
   <tag></tag>
   <elementGuidId>b0c78892-5a1d-4d9a-9281-95a880202086</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='annu@cid08.com'])[2]/following::span[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>label</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='annu@cid08.com'])[2]/following::span[1]</value>
   </webElementProperties>
</WebElementEntity>
