<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Editpermission</name>
   <tag></tag>
   <elementGuidId>b16d920d-4dca-4f7b-8067-d5b387c86b5c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>id(&quot;shareUsersList&quot;)/tr[54]/td[@class=&quot;col-xs-2&quot;]/label[@class=&quot;radio shrusrWrkRadio&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>label</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;shareUsersList&quot;)/tr[54]/td[@class=&quot;col-xs-2&quot;]/label[@class=&quot;radio shrusrWrkRadio&quot;]</value>
   </webElementProperties>
</WebElementEntity>
