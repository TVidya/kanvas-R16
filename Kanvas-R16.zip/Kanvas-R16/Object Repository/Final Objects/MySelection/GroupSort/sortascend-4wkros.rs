<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>sortascend-4wkros</name>
   <tag></tag>
   <elementGuidId>c3ed2380-d36f-4c23-916d-517e0dac08e9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>id(&quot;grp-sort-modal-ul-measure&quot;)/li[@class=&quot;gsortli gsortLiVisible oddBackGrnd_li&quot;]/span[@class=&quot;grpsort-icon-btn sort-icon-sm-darkgrey&quot;][count(. | //span[@data-grpsort = '4wkros']) = count(//span[@data-grpsort = '4wkros'])]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;grp-sort-modal-ul-measure&quot;)/li[@class=&quot;gsortli gsortLiVisible oddBackGrnd_li&quot;]/span[@class=&quot;grpsort-icon-btn sort-icon-sm-darkgrey&quot;]</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-grpsort</name>
      <type>Main</type>
      <value>4wkros</value>
   </webElementProperties>
</WebElementEntity>
