<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>t1</name>
   <tag></tag>
   <elementGuidId>1b008a58-a554-49cc-9ae4-58cd1bc94075</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
